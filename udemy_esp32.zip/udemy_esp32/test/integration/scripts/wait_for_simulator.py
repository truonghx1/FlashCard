#!/usr/bin/env python3
"""Cho den khi Wokwi RFC2217 serial san sang.

Usage:
    python test/integration/scripts/wait_for_simulator.py \
        --url rfc2217://localhost:4000 \
        --baud-rate 115200 \
        --timeout 30

Exit code:
    0  ket noi thanh cong
    1  timeout hoac ket noi that bai
"""

from __future__ import annotations

import argparse
import sys
import time

import serial  # pyserial

DEFAULT_URL = "rfc2217://localhost:4000"
DEFAULT_BAUD_RATE = 115200
DEFAULT_TIMEOUT_S = 30.0
RETRY_INTERVAL_S = 1.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Wait until the Wokwi RFC2217 serial port is accepting connections."
    )
    parser.add_argument("--url", default=DEFAULT_URL, help=f"Serial URL (default: {DEFAULT_URL})")
    parser.add_argument(
        "--baud-rate", type=int, default=DEFAULT_BAUD_RATE,
        help=f"Baud rate (default: {DEFAULT_BAUD_RATE})",
    )
    parser.add_argument(
        "--timeout", type=float, default=DEFAULT_TIMEOUT_S,
        help=f"Total wait timeout in seconds (default: {DEFAULT_TIMEOUT_S})",
    )
    return parser.parse_args()


def try_connect(url: str, baud_rate: int) -> bool:
    """Thu mo va dong mot ket noi serial. Tra ve True neu thanh cong."""
    conn = None
    try:
        conn = serial.serial_for_url(url, baudrate=baud_rate, timeout=1)
        return True
    except Exception as exc:  # noqa: BLE001 - in ngan gon, tiep tuc retry
        print(f"  not ready: {type(exc).__name__}: {exc}")
        return False
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:  # noqa: BLE001
                pass


def main() -> int:
    args = parse_args()
    print(f"Waiting for simulator at {args.url} (baud {args.baud_rate}, timeout {args.timeout}s)")

    deadline = time.monotonic() + args.timeout
    attempt = 0
    while time.monotonic() < deadline:
        attempt += 1
        print(f"Attempt {attempt}...")
        if try_connect(args.url, args.baud_rate):
            print(f"OK: simulator serial is available at {args.url}")
            return 0
        # Sleep ngan, co gioi han boi deadline ben ngoai
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(RETRY_INTERVAL_S, remaining))

    print(f"FAIL: simulator serial not available at {args.url} after {args.timeout}s")
    return 1


if __name__ == "__main__":
    sys.exit(main())
