"""Integration tests qua Wokwi Simulator + RFC2217 serial.

Moi expected pattern deu lay truc tiep tu production source:
    - "Starting wifi application"            (main/wifi_app.c, wifi_app_start)
    - "WIFI_EVENT_AP_START"                  (main/wifi_app.c, event handler)
    - "WIFI_APP_MSG_LOAD_SAVED_CREDENTIALS"  (main/wifi_app.c, wifi_app_task)
    - "Loaded station configuration" /
      "Unable to load station configuration" (main/wifi_app.c, wifi_app_task)
    - "WIFI_APP_MSG_START_HTTP_SERVER"       (main/wifi_app.c, wifi_app_task)
    - "Starting reading input from pin 19"   (main/gpio.c, gpio_task; GPIO_INPUT_PIN=19)
    - "Data read:: <n>"                      (main/gpio.c, gpio_task, chu ky 1 giay)
    - "AWS IoT SDK Version"                  (main/aws_iot.c, aws_iot_task)

Luu y: firmware KHONG co UART command interface (khong console REPL),
nen khong the gui command qua serial (xem test_end_to_end_serial_command).
"""

from __future__ import annotations

import pytest

from conftest import (
    format_serial_diagnostics,
    read_serial_count,
    read_serial_until,
)

pytestmark = [pytest.mark.simulation, pytest.mark.serial]

# ---------------------------------------------------------------------------
# Expected patterns (chi dung chuoi co that trong source)
# ---------------------------------------------------------------------------

# Log boot mot lan (chi thay neu attach serial truoc/khi firmware boot)
BOOT_ONESHOT_PATTERNS = (
    r"Starting wifi application"
    r"|WIFI_EVENT_AP_START"
    r"|WIFI_APP_MSG_LOAD_SAVED_CREDENTIALS"
    r"|Starting reading input from pin 19"
)

# Log lap lai theo chu ky (bang chung firmware dang chay, du attach muon)
PERIODIC_PATTERNS = (
    r"Data read:: -?\d+"
)

# Bang chung application task da khoi tao xong:
# gpio_task in "Data read:: <n>" moi 1 giay sau khi task chay
APP_READY_PATTERN = r"Data read:: (-?\d+)"


class TestSimulatorAvailability:
    """Test 1: Python ket noi duoc toi RFC2217 port."""

    def test_simulator_serial_available(self, serial_conn):
        # Fixture serial_conn da fail voi thong bao ro rang neu Wokwi chua chay.
        # Ket noi thanh cong CHI chung minh RFC2217 server dang mo,
        # KHONG chung minh firmware hoat dong (cac test sau kiem tra dieu do).
        assert serial_conn.is_open, "Serial connection phai o trang thai open"


class TestFirmwareBoot:
    """Test 2: bang chung firmware da boot (log co that trong source)."""

    def test_firmware_boot_evidence(self, serial_conn, serial_config):
        # Chap nhan MOT trong hai loai bang chung:
        #   - boot log mot lan (neu attach kip luc boot)
        #   - log chu ky cua gpio_task (neu attach sau khi boot xong)
        # -> khong phu thuoc thu tu log hay timestamp.
        combined = f"(?:{BOOT_ONESHOT_PATTERNS})|(?:{PERIODIC_PATTERNS})"
        match, captured = read_serial_until(
            serial_conn, combined, timeout_s=serial_config.timeout_s
        )
        assert match is not None, (
            "Khong tim thay bang chung firmware boot trong "
            f"{serial_config.timeout_s}s.\n"
            f"Expected (regex): {combined}\n"
            f"--- Serial output da thu duoc ---\n"
            f"{format_serial_diagnostics(captured)}"
        )


class TestApplicationReadiness:
    """Test 3: application task da khoi tao va dang chay."""

    def test_gpio_task_emits_periodic_readings(self, serial_conn, serial_config):
        # gpio_task (main/gpio.c) in "Data read:: <n>" moi ~1 giay.
        # Thay >= 2 lan trong deadline => task da duoc tao va scheduler dang
        # chay no lap lai (khong phai log sot lai mot lan trong buffer).
        count, captured = read_serial_count(
            serial_conn,
            APP_READY_PATTERN,
            min_count=2,
            timeout_s=serial_config.timeout_s,
        )
        assert count >= 2, (
            f"Chi thay {count} dong 'Data read::' trong {serial_config.timeout_s}s "
            "(can >= 2 de chung minh gpio_task dang chay dinh ky).\n"
            f"--- Serial output da thu duoc ---\n"
            f"{format_serial_diagnostics(captured)}"
        )


class TestEndToEndSerialCommand:
    """Test 4: end-to-end serial command flow."""

    @pytest.mark.skip(
        reason=(
            "BLOCKED_BY_INTERFACE: firmware khong co UART command interface. "
            "main/ khong dang ky console/REPL va khong doc UART input "
            "(chi ghi log ra serial). Khong the gui command hop le/khong hop le "
            "qua serial ma khong sua production code."
        )
    )
    def test_serial_command_round_trip(self):
        pass  # pragma: no cover - bi skip co chu dich


class TestSensorToTaskFlow:
    """Test 5: GPIO input -> gpio_task -> serial log.

    Luong co that trong source: gpio_task doc GPIO 19 (pulldown) moi 1 giay
    va in "Data read:: <0|1>". Trong diagram.json, GPIO 19 noi voi pushbutton
    keo len 3V3 (nhan = 1, tha = 0).

    Gioi han: chua the tu dong nhan button tu Python qua RFC2217, nen test
    tu dong chi xac nhan gia tri doc duoc hop le voi cau hinh mach (0 hoac 1).
    Kich ban nhan button thu cong duoc mo ta trong README.md.
    """

    def test_gpio_readings_match_wiring(self, serial_conn, serial_config):
        count, captured = read_serial_count(
            serial_conn,
            APP_READY_PATTERN,
            min_count=2,
            timeout_s=serial_config.timeout_s,
        )
        assert count >= 2, (
            "Khong thu duoc du 2 dong 'Data read::' de danh gia.\n"
            f"--- Serial output da thu duoc ---\n"
            f"{format_serial_diagnostics(captured)}"
        )
        import re

        values = {m.group(1) for m in re.finditer(APP_READY_PATTERN, captured)}
        # GPIO 19 la digital input pulldown: gia tri hop le chi co 0 hoac 1.
        assert values <= {"0", "1"}, (
            f"Gia tri GPIO ngoai pham vi digital 0/1: {sorted(values)}\n"
            f"--- Serial output da thu duoc ---\n"
            f"{format_serial_diagnostics(captured)}"
        )


class TestNetworkFlow:
    """Test 6: network flow (Wi-Fi / MQTT AWS IoT)."""

    @pytest.mark.skip(
        reason=(
            "Chua thuc thi duoc trong simulation: firmware boot o che do SoftAP "
            "('ESP32_APP') de nhan cau hinh Wi-Fi qua HTTP; Wokwi khong mo phong "
            "SoftAP client ket noi vao. aws_iot_task ket noi AWS IoT MQTT TLS "
            "bang certificate that (main/certs/) toi endpoint production - "
            "bi cam dung trong test. Prerequisite: local MQTT broker + "
            "endpoint/cert test rieng (xem README.md)."
        )
    )
    def test_network_flow(self):
        pass  # pragma: no cover - bi skip co chu dich
