# Giai đoạn 3 — Integration Test (Wokwi Simulator + RFC2217 + pytest)

Kiểm tra luồng tích hợp của firmware ESP32 **không cần board thật**, bằng
Wokwi Simulator chạy trong VS Code. Python test giao tiếp với firmware qua
Serial được forward theo RFC2217 tại `rfc2217://localhost:4000`.

> Trạng thái: **NOT_EXECUTED** — cấu hình và test đã được chuẩn bị sẵn,
> chưa build firmware, chưa chạy simulator, chưa execute test.

## Luồng tích hợp được kiểm tra

```
Pushbutton (GPIO 19, Wokwi)          Boot flow
        │                            app_main → nvs_flash_init
        ▼                                    → wifi_app_start
ESP-IDF gpio driver                          → wifi_app_task (FreeRTOS queue)
        │                                    → "Starting wifi application"
        ▼                                    → WIFI_APP_MSG_LOAD_SAVED_CREDENTIALS
gpio_task (FreeRTOS, core 1)                 → WIFI_APP_MSG_START_HTTP_SERVER
        │  đọc mỗi 1 giây                    → WIFI_EVENT_AP_START
        ▼
Serial log "Data read:: <0|1>"  ◄── quan sát qua rfc2217://localhost:4000
```

Mọi expected pattern trong test đều lấy nguyên văn từ production source
(`main/gpio.c`, `main/wifi_app.c`, `main/aws_iot.c`).

## Cấu trúc file

```
wokwi.toml                                # (root) cấu hình Wokwi, RFC2217 port 4000
diagram.json                              # (root) ESP32 DevKit C v4 + LED/button theo GPIO thật
test/integration/
├── README.md                             # file này
├── requirements.txt                      # pytest + pyserial
├── pytest.ini                            # testpaths, markers simulation/serial
├── conftest.py                           # serial fixture + helpers (deadline monotonic)
├── scripts/
│   └── wait_for_simulator.py             # chờ RFC2217 sẵn sàng, exit code 0/1
└── tests/
    └── test_serial_integration.py        # 6 integration test
```

GPIO mapping trong `diagram.json` (lấy từ source, không tự đoán):

| GPIO | Định nghĩa trong source | Linh kiện Wokwi |
|---|---|---|
| 18 | `GPIO_CONTROL_PIN` ([main/gpio.h](../../main/gpio.h)) | LED xanh dương |
| 19 | `GPIO_INPUT_PIN` (input, pulldown) | Pushbutton → 3V3 (nhấn = 1) |
| 21/22/23 | `RGB_LED_RED/GREEN/YELLOW_GPIO` ([main/rgb_led.h](../../main/rgb_led.h)) | 3 LED |
| 0 | `WIFI_RESET_BUTTON` ([main/wifi_reset_button.h](../../main/wifi_reset_button.h)) | Pushbutton → GND + pull-up 10k |

## Prerequisites

- ESP-IDF extension/toolchain đã hoạt động trong VS Code (project này build bằng ESP-IDF).
- Python 3.
- **Wokwi for VS Code** extension (`wokwi.wokwi-vscode`).
- Wokwi license nếu extension yêu cầu (`Wokwi: Request a new license` trong Command Palette).
- Python virtual environment (khuyến nghị).

## 1. Install Python dependencies

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r test/integration/requirements.txt
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r test/integration/requirements.txt
```

## 2. Build firmware (bạn tự chạy)

```
idf.py set-target esp32
idf.py build
```

Build sẽ tạo ra các file mà `wokwi.toml` trỏ tới:

- `build/flasher_args.json`
- `build/udemy_esp32_app_test.elf` (tên project trong root [CMakeLists.txt](../../CMakeLists.txt))

## 3. Start simulator (bạn tự chạy)

Trong VS Code:

1. Mở Command Palette bằng `F1`.
2. Chạy `Wokwi: Start Simulator`.
3. Giữ tab simulator đang hiển thị (simulator có thể pause khi tab bị ẩn).
4. Đợi firmware boot (thấy log trong tab simulator).

## 4. Check RFC2217 connection

```
python test/integration/scripts/wait_for_simulator.py
```

Tùy chọn:

```
python test/integration/scripts/wait_for_simulator.py --url rfc2217://localhost:4000 --baud-rate 115200 --timeout 30
```

Exit code `0` = sẵn sàng, khác `0` = chưa kết nối được.

## 5. Run tests

```
python -m pytest test/integration/tests -v
```

## Environment overrides

PowerShell:

```powershell
$env:ESP32_SERIAL_URL="rfc2217://localhost:4000"
$env:ESP32_BAUD_RATE="115200"
$env:ESP32_TEST_TIMEOUT="20"
```

Linux/macOS:

```bash
export ESP32_SERIAL_URL="rfc2217://localhost:4000"
export ESP32_BAUD_RATE="115200"
export ESP32_TEST_TIMEOUT="20"
```

Baud rate mặc định 115200 khớp `CONFIG_ESP_CONSOLE_UART_BAUDRATE=115200` trong `sdkconfig`.

## Danh sách test và điều kiện thực thi

| Test | Nội dung | Điều kiện |
|---|---|---|
| 1. `test_simulator_serial_available` | Kết nối được RFC2217 | Wokwi đang chạy |
| 2. `test_firmware_boot_evidence` | Tìm log boot thật (`Starting wifi application`, `WIFI_EVENT_AP_START`, ...) hoặc log chu kỳ (`Data read::`) | Firmware đã boot |
| 3. `test_gpio_task_emits_periodic_readings` | `gpio_task` in `Data read:: <n>` ≥ 2 lần → task đang chạy định kỳ | Firmware đang chạy |
| 4. `test_serial_command_round_trip` | **SKIP — `BLOCKED_BY_INTERFACE`**: firmware không có UART command interface (không console/REPL, không đọc UART input) | Cần production code bổ sung console (ngoài phạm vi) |
| 5. `test_gpio_readings_match_wiring` | Giá trị `Data read::` chỉ được là 0/1 (digital input pulldown) | Firmware đang chạy |
| 6. `test_network_flow` | **SKIP**: cần local MQTT broker + credential test riêng | Xem Limitations |

### Test design thủ công (chưa tự động hóa được)

Chưa thể tự động nhấn pushbutton trong Wokwi từ Python qua RFC2217. Kịch bản
thủ công cho luồng sensor→task:

1. Chạy test 3/5 để xác nhận baseline `Data read:: 0`.
2. Trong tab Wokwi, nhấn giữ button **GPIO19 INPUT**.
3. Quan sát serial log chuyển sang `Data read:: 1` (trong ≤ 2 giây).
4. Thả button → log trở về `Data read:: 0`.

Tương tự, nhấn button **GPIO0 WIFI RESET** phải tạo log
`WIFI RESET BUTTON INTERRUPT OCCURRED` và
`WIFI_APP_MSG_USER_REQUESTED_STA_DISCONNECT` (từ `main/wifi_reset_button.c`,
`main/wifi_app.c`).

## Troubleshooting

| Vấn đề | Cách xử lý |
|---|---|
| `build/flasher_args.json` chưa tồn tại | Chưa build. Chạy `idf.py build` từ root repository. |
| ELF path sai / Wokwi báo không tìm thấy ELF | Kiểm tra `build/udemy_esp32_app_test.elf` tồn tại. Nếu đổi `project(...)` trong root CMakeLists.txt, cập nhật `elf` trong `wokwi.toml`. |
| Wokwi chưa được start | `F1` → `Wokwi: Start Simulator`. Kiểm tra extension đã cài và có license. |
| Port 4000 đang được dùng | Đổi `rfc2217ServerPort` trong `wokwi.toml` (ví dụ 4001) và set `ESP32_SERIAL_URL=rfc2217://localhost:4001`. |
| Python không kết nối được RFC2217 | Chạy `wait_for_simulator.py` để xem lỗi chi tiết. Kiểm tra firewall/localhost. Simulator phải đang chạy TRƯỚC khi test chạy. |
| Không nhận được boot log | Boot log chỉ phát một lần; nếu attach muộn, test 2 vẫn pass nhờ log chu kỳ `Data read::`. Nếu hoàn toàn im lặng: kiểm tra tab simulator không bị pause. |
| Simulator tab bị pause hoặc không hiển thị | Giữ tab Wokwi visible; nhấn nút Play nếu đang pause. |
| Baud rate không khớp | Serial console của project là 115200 (`sdkconfig`). Không đổi `ESP32_BAUD_RATE` trừ khi đã đổi `CONFIG_ESP_CONSOLE_UART_BAUDRATE`. |
| Expected log đã thay đổi | Nếu production code sửa message log, cập nhật pattern trong `tests/test_serial_integration.py` cho khớp source mới. |
| Target chip không khớp diagram | `sdkconfig` đặt `CONFIG_IDF_TARGET="esp32"`; `diagram.json` dùng `board-esp32-devkit-c-v4`. Nếu đổi target (S3/C3...), phải đổi board trong `diagram.json`. |

## Limitations

- Simulator **không thay thế hoàn toàn phần cứng thật**: timing, RF, điện áp,
  nhiễu, hiệu năng và hành vi peripheral có thể khác board thật.
- Wokwi không mô phỏng SoftAP có client kết nối vào → luồng HTTP server
  (cấu hình Wi-Fi qua trang web) và AWS IoT MQTT TLS chưa kiểm tra được
  trong simulation. AWS IoT dùng certificate thật trong `main/certs/` và
  endpoint production — **không được dùng trong test**.
- Chưa tự động điều khiển được linh kiện Wokwi (button) từ Python → luồng
  button chỉ có kịch bản thủ công (ở trên).
- Kết quả simulation phải được xác minh lại trên ESP32 thật trước khi release.
- **Các test trong nhiệm vụ này chưa được build hoặc execute.**
