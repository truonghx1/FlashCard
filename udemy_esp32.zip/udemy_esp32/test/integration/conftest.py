"""Pytest fixtures va helper cho Integration Test qua Wokwi RFC2217 serial.

Khong hardcode COM port hay /dev/ttyUSB*. Ket noi bang serial.serial_for_url()
voi URL RFC2217 (default rfc2217://localhost:4000).

Environment overrides:
    ESP32_SERIAL_URL    default: rfc2217://localhost:4000
    ESP32_BAUD_RATE     default: 115200
    ESP32_TEST_TIMEOUT  default: 15 (giay)
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from typing import Optional, Pattern, Tuple, Union

import pytest
import serial  # pyserial

DEFAULT_SERIAL_URL = "rfc2217://localhost:4000"
DEFAULT_BAUD_RATE = 115200
DEFAULT_TIMEOUT_S = 15.0

# Timeout cho MOT lan doc serial (khong phai timeout toan test)
READ_CHUNK_TIMEOUT_S = 0.5


@dataclass(frozen=True)
class SerialConfig:
    """Cau hinh serial doc tu environment variables."""

    url: str
    baud_rate: int
    timeout_s: float


@pytest.fixture(scope="session")
def serial_config() -> SerialConfig:
    """Doc cau hinh serial tu environment, co default hop ly."""
    return SerialConfig(
        url=os.environ.get("ESP32_SERIAL_URL", DEFAULT_SERIAL_URL),
        baud_rate=int(os.environ.get("ESP32_BAUD_RATE", str(DEFAULT_BAUD_RATE))),
        timeout_s=float(os.environ.get("ESP32_TEST_TIMEOUT", str(DEFAULT_TIMEOUT_S))),
    )


@pytest.fixture()
def serial_conn(serial_config: SerialConfig):
    """Mo ket noi serial toi Wokwi simulator; dong lai trong finally.

    Neu simulator chua chay, test fail voi thong bao ro rang
    (khong bien loi ket noi thanh PASS).
    """
    conn: Optional[serial.Serial] = None
    try:
        try:
            conn = serial.serial_for_url(
                serial_config.url,
                baudrate=serial_config.baud_rate,
                timeout=READ_CHUNK_TIMEOUT_S,
            )
        except Exception as exc:  # noqa: BLE001 - bao loi ket noi ro rang
            pytest.fail(
                f"Wokwi simulator is not available at {serial_config.url} "
                f"(baud {serial_config.baud_rate}). "
                f"Hay start Wokwi trong VS Code truoc khi chay test. "
                f"Chi tiet: {type(exc).__name__}: {exc}",
                pytrace=False,
            )

        # Bo du lieu ton dong de test bat dau tu trang thai sach
        try:
            conn.reset_input_buffer()
        except Exception:  # noqa: BLE001 - mot so URL handler khong ho tro
            pass

        yield conn
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:  # noqa: BLE001 - dong best-effort
                pass


# ---------------------------------------------------------------------------
# Helper functions (deadline dua tren time.monotonic, khong sleep tuy y)
# ---------------------------------------------------------------------------

def _normalize(text: bytes) -> str:
    """Decode bytes -> str va chuan hoa CRLF/LF ve LF."""
    return text.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def read_serial_until(
    conn: serial.Serial,
    pattern: Union[str, Pattern[str]],
    timeout_s: float,
) -> Tuple[Optional["re.Match[str]"], str]:
    """Doc serial cho den khi regex `pattern` khop hoac het deadline.

    Returns:
        (match, captured_text): match la re.Match neu tim thay, None neu timeout.
        captured_text luon chua TOAN BO output da thu duoc (phuc vu debug).
    """
    regex = re.compile(pattern) if isinstance(pattern, str) else pattern
    deadline = time.monotonic() + timeout_s
    captured = ""

    while time.monotonic() < deadline:
        # conn.timeout (READ_CHUNK_TIMEOUT_S) gioi han moi lan read -> khong block vo han
        chunk = conn.read(256)
        if chunk:
            captured += _normalize(chunk)
            match = regex.search(captured)
            if match:
                return match, captured

    return None, captured


def read_serial_count(
    conn: serial.Serial,
    pattern: Union[str, Pattern[str]],
    min_count: int,
    timeout_s: float,
) -> Tuple[int, str]:
    """Dem so lan regex `pattern` xuat hien cho den khi du `min_count`
    hoac het deadline.

    Returns:
        (count, captured_text)
    """
    regex = re.compile(pattern) if isinstance(pattern, str) else pattern
    deadline = time.monotonic() + timeout_s
    captured = ""

    while time.monotonic() < deadline:
        chunk = conn.read(256)
        if chunk:
            captured += _normalize(chunk)
            count = len(regex.findall(captured))
            if count >= min_count:
                return count, captured

    return len(regex.findall(captured)), captured


def send_line(conn: serial.Serial, line: str) -> None:
    """Gui mot dong voi line ending CRLF (chuan console UART)."""
    conn.write(line.encode("utf-8") + b"\r\n")
    conn.flush()


def format_serial_diagnostics(captured: str, max_chars: int = 4000) -> str:
    """Chuan bi phan serial output da thu duoc de in ra khi test fail."""
    if not captured:
        return "<khong nhan duoc byte nao tu serial>"
    tail = captured[-max_chars:]
    prefix = "...(truncated)...\n" if len(captured) > max_chars else ""
    return f"{prefix}{tail}"
