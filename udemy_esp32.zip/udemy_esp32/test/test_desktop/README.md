# Giai đoạn 1 — Native Unit Test (GoogleTest + CMake + CTest)

Test chạy **trên PC** (GCC/Clang/MSVC), không cần ESP32, không cần ESP-IDF,
không flash board, không dùng `idf.py`.

## Trạng thái hiện tại: `BLOCKED`

Tất cả module trong `main/` đều include trực tiếp header ESP-IDF / FreeRTOS /
driver phần cứng ngay đầu file, nên **không module nào compile được native
trên PC mà không sửa production code** (việc sửa production code nằm ngoài
phạm vi Giai đoạn 1):

| Module | Dependency chặn native build |
|---|---|
| `main/app_nvs.c` | `nvs_flash.h`, `esp_log.h`, `wifi_config_t` (esp_wifi) |
| `main/aws_iot.c` | AWS IoT SDK, FreeRTOS, `cJSON` (component ESP-IDF), `esp_log.h` |
| `main/gpio.c` | `driver/gpio.h`, FreeRTOS task |
| `main/http_server.c` | `esp_http_server`, `esp_ota_ops`, FreeRTOS queue/timer |
| `main/rgb_led.c` | `driver/ledc.h` |
| `main/sntp_time_sync.c` | `lwip/apps/sntp.h`, FreeRTOS, `esp_log.h` |
| `main/wifi_app.c` | `esp_wifi`, FreeRTOS |
| `main/wifi_reset_button.c` | `driver/gpio.h`, FreeRTOS semaphore/ISR |
| `main/main.c` | tất cả module trên |

Toàn bộ hạ tầng test (CMake + GoogleTest + testcase) đã được chuẩn bị **sẵn
sàng** trong thư mục này. Chỉ cần mở khóa theo mục
[Kích hoạt test module thật](#kích-hoạt-test-module-thật) bên dưới.

## Cấu trúc

```
test/test_desktop/
├── CMakeLists.txt            # Project native: GoogleTest v1.14.0 (pinned), CTest
├── test_sanity.cpp           # Self-check harness (luôn được build)
├── test_command_parser.cpp   # Testcase SẴN cho module command_parser (chờ kích hoạt)
└── README.md                 # File này
```

Build output nằm ở `build/test_desktop/` (ngoài thư mục source test).

## Yêu cầu môi trường

- CMake >= 3.16
- Một compiler C/C++ native trên PC:
  - Windows: MinGW-w64 (GCC), LLVM/Clang, hoặc Visual Studio (MSVC)
  - Linux/macOS: GCC hoặc Clang
- Kết nối mạng ở lần configure đầu tiên (FetchContent tải GoogleTest
  `v1.14.0` từ GitHub, có kiểm tra SHA256). Các lần sau dùng cache trong
  `build/test_desktop/_deps/`.

## Lệnh build và chạy test

Chạy **từ root repository** (`udemy_esp32/`):

```powershell
# 1) Configure
cmake -S test/test_desktop -B build/test_desktop -DCMAKE_BUILD_TYPE=Debug

# 2) Build
cmake --build build/test_desktop --parallel

# 3) Chạy test
ctest --test-dir build/test_desktop --output-on-failure
```

Ghi chú Windows:

- Với MinGW: thêm `-G "MinGW Makefiles"` (hoặc `-G Ninja` nếu có Ninja) vào
  lệnh configure nếu CMake mặc định chọn Visual Studio mà bạn không muốn.
- Với Visual Studio generator (multi-config), bước 2 và 3 cần chỉ định config:

  ```powershell
  cmake --build build/test_desktop --parallel --config Debug
  ctest --test-dir build/test_desktop -C Debug --output-on-failure
  ```

Kết quả mong đợi ở cấu hình mặc định: các test `HarnessSanity.*` pass —
xác nhận toolchain + GoogleTest + CTest hoạt động.

## Kích hoạt test module thật

Testcase trong `test_command_parser.cpp` đã viết sẵn cho logic parse JSON
command hiện đang nằm **bên trong** `iot_subscribe_callback_handler()` của
`main/aws_iot.c` (payload `{"command":"LED_ON"|"LED_OFF"}`).

Điều kiện kích hoạt: tách logic đó ra một module thuần túy (việc refactor
này do người phụ trách production code thực hiện, KHÔNG thuộc phạm vi test):

1. Tạo `main/command_parser.h` với API:

   ```c
   #ifndef MAIN_COMMAND_PARSER_H_
   #define MAIN_COMMAND_PARSER_H_

   #include <stddef.h>

   typedef enum {
       APP_CMD_LED_ON = 0,
       APP_CMD_LED_OFF,
       APP_CMD_UNKNOWN,     /* JSON hợp lệ nhưng command không hỗ trợ/thiếu/sai kiểu */
       APP_CMD_PARSE_ERROR  /* NULL, rỗng, hoặc JSON sai định dạng */
   } app_command_t;

   app_command_t command_parser_parse(const char *payload, size_t len);

   #endif
   ```

2. Tạo `main/command_parser.c` hiện thực hàm trên (chỉ phụ thuộc libc +
   cJSON), rồi cho `aws_iot.c` gọi lại module này.

3. Configure lại với option bật:

   ```powershell
   cmake -S test/test_desktop -B build/test_desktop -DCMAKE_BUILD_TYPE=Debug -DENABLE_COMMAND_PARSER_TESTS=ON
   cmake --build build/test_desktop --parallel
   ctest --test-dir build/test_desktop --output-on-failure
   ```

   CMake sẽ compile **trực tiếp** `main/command_parser.c` (không copy) vào
   static library `command_parser_lib` và link với `desktop_unit_tests`.

   Lưu ý: nếu `command_parser.c` dùng cJSON, cần bổ sung nguồn cJSON native
   vào `command_parser_lib` trong `CMakeLists.txt` (ví dụ FetchContent
   `DaveGamble/cJSON` pinned tag) — phần này chỉ chỉnh trong
   `test/test_desktop/CMakeLists.txt`.

## Danh sách testcase đã chuẩn bị

`test_sanity.cpp` (build mặc định — self-check harness, không phải test production):

- `HarnessSanity.GoogleTestExecutesAndReportsSuccess`
- `HarnessSanity.Cpp17IsAvailable`
- `HarnessSanity.FixedWidthIntegerSizesMatchEsp32Assumptions`
- `HarnessSanity.StdStringBehavesDeterministically`

`test_command_parser.cpp` (chờ `ENABLE_COMMAND_PARSER_TESTS=ON`):

- Hợp lệ: `ParsesLedOnCommand`, `ParsesLedOffCommand`,
  `IgnoresAdditionalJsonKeys`, `AcceptsWhitespaceAroundJson`
- Ngữ nghĩa sai: `ReturnsUnknownForUnsupportedCommand`,
  `CommandComparisonIsCaseSensitive`, `ReturnsUnknownWhenCommandKeyMissing`,
  `ReturnsUnknownWhenCommandValueIsNotString`,
  `ReturnsUnknownForEmptyJsonObject`
- Input lỗi/biên: `ReturnsParseErrorForMalformedJson`,
  `ReturnsParseErrorForEmptyInput`, `ReturnsParseErrorForNullPointer`,
  `RespectsExplicitLengthOverNulTerminator`,
  `ReturnsParseErrorForTruncatedPayloadLength`

## Quy tắc phạm vi

- Chỉ tạo/chỉnh file trong `test/test_desktop/`.
- Không sửa `main/`, không sửa CMakeLists.txt của root/`main/`.
- Không copy production code vào thư mục test.
- Không dùng `idf.py`, không flash board, không target test.
