// =============================================================================
// test_sanity.cpp
//
// Self-check cho test harness (GoogleTest + CMake + CTest) trên PC.
// Đây KHÔNG phải test cho production code. Mục đích:
//   - Xác nhận toolchain native (GCC/Clang/MSVC) build được C++17.
//   - Xác nhận GoogleTest được FetchContent tải và link đúng.
//   - Xác nhận CTest discover và execute test thành công.
//
// Khi module production native-compatible đầu tiên sẵn sàng
// (xem test_command_parser.cpp và README.md), file này vẫn giữ nguyên
// để làm baseline cho harness.
// =============================================================================

#include <gtest/gtest.h>

#include <cstdint>
#include <string>

namespace
{

TEST(HarnessSanity, GoogleTestExecutesAndReportsSuccess)
{
    SUCCEED();
}

TEST(HarnessSanity, Cpp17IsAvailable)
{
    static_assert(__cplusplus >= 201703L, "Can C++17 tro len cho GoogleTest");
    SUCCEED();
}

TEST(HarnessSanity, FixedWidthIntegerSizesMatchEsp32Assumptions)
{
    // Production code ESP32 giả định các kích thước fixed-width chuẩn.
    // Native test trên PC phải có cùng giả định để kết quả tin cậy được.
    EXPECT_EQ(sizeof(std::uint8_t), 1u);
    EXPECT_EQ(sizeof(std::uint16_t), 2u);
    EXPECT_EQ(sizeof(std::uint32_t), 4u);
    EXPECT_EQ(sizeof(std::uint64_t), 8u);
}

TEST(HarnessSanity, StdStringBehavesDeterministically)
{
    const std::string value = "esp32";
    EXPECT_EQ(value.size(), 5u);
    EXPECT_EQ(value, std::string("esp") + "32");
}

} // namespace
