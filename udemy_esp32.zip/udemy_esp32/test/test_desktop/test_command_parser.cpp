// =============================================================================
// test_command_parser.cpp
//
// Bộ Native Unit Test SẴN SÀNG cho module `command_parser`.
//
// TRẠNG THÁI: chưa được compile (mặc định) vì module production chưa tồn tại.
// File này chỉ được thêm vào build khi configure với:
//   -DENABLE_COMMAND_PARSER_TESTS=ON
//
// BỐI CẢNH:
// Hiện tại logic parse JSON command nằm bên trong hàm
// `iot_subscribe_callback_handler()` của main/aws_iot.c, trộn lẫn với
// AWS IoT SDK types (AWS_IoT_Client, IoT_Publish_Message_Params) và
// side-effect phần cứng (`set_gpio_control_value()`), nên KHÔNG thể
// test native mà không refactor production code.
//
// API MONG ĐỢI sau khi tách logic ra main/command_parser.{h,c}
// (module thuần túy, chỉ phụ thuộc libc + cJSON):
//
//   typedef enum {
//       APP_CMD_LED_ON = 0,     // payload: {"command":"LED_ON"}
//       APP_CMD_LED_OFF,        // payload: {"command":"LED_OFF"}
//       APP_CMD_UNKNOWN,        // JSON hợp lệ nhưng command không hỗ trợ
//                               // hoặc thiếu key "command" / sai kiểu
//       APP_CMD_PARSE_ERROR     // input NULL / rỗng / JSON sai định dạng
//   } app_command_t;
//
//   app_command_t command_parser_parse(const char *payload, size_t len);
//
// Hành vi mong đợi được suy ra 1:1 từ code hiện có trong aws_iot.c:
//   - So sánh chuỗi command phân biệt hoa thường (strcmp / CaseSensitive).
//   - Chỉ "LED_ON" và "LED_OFF" là command hợp lệ.
//   - Key "command" phải là string.
// =============================================================================

#include <gtest/gtest.h>

#include <cstddef>
#include <cstring>
#include <string>

extern "C"
{
#include "command_parser.h"
}

namespace
{

// Helper: parse chuỗi C++ tiện dụng trong test.
app_command_t Parse(const std::string &payload)
{
    return command_parser_parse(payload.c_str(), payload.size());
}

// ---------------------------------------------------------------------------
// Trường hợp hợp lệ thông thường
// ---------------------------------------------------------------------------

TEST(CommandParser, ParsesLedOnCommand)
{
    EXPECT_EQ(Parse(R"({"command":"LED_ON"})"), APP_CMD_LED_ON);
}

TEST(CommandParser, ParsesLedOffCommand)
{
    EXPECT_EQ(Parse(R"({"command":"LED_OFF"})"), APP_CMD_LED_OFF);
}

TEST(CommandParser, IgnoresAdditionalJsonKeys)
{
    EXPECT_EQ(Parse(R"({"device":"esp32","command":"LED_ON","ts":123})"),
              APP_CMD_LED_ON);
}

TEST(CommandParser, AcceptsWhitespaceAroundJson)
{
    EXPECT_EQ(Parse("  \t\n{\"command\":\"LED_OFF\"}\n "), APP_CMD_LED_OFF);
}

// ---------------------------------------------------------------------------
// Command không hỗ trợ / sai ngữ nghĩa (JSON vẫn hợp lệ)
// ---------------------------------------------------------------------------

TEST(CommandParser, ReturnsUnknownForUnsupportedCommand)
{
    EXPECT_EQ(Parse(R"({"command":"LED_BLINK"})"), APP_CMD_UNKNOWN);
}

TEST(CommandParser, CommandComparisonIsCaseSensitive)
{
    // aws_iot.c dùng strcmp + cJSON_GetObjectItemCaseSensitive
    EXPECT_EQ(Parse(R"({"command":"led_on"})"), APP_CMD_UNKNOWN);
    EXPECT_EQ(Parse(R"({"Command":"LED_ON"})"), APP_CMD_UNKNOWN);
}

TEST(CommandParser, ReturnsUnknownWhenCommandKeyMissing)
{
    EXPECT_EQ(Parse(R"({"status":"LED_ON"})"), APP_CMD_UNKNOWN);
}

TEST(CommandParser, ReturnsUnknownWhenCommandValueIsNotString)
{
    EXPECT_EQ(Parse(R"({"command":1})"), APP_CMD_UNKNOWN);
    EXPECT_EQ(Parse(R"({"command":null})"), APP_CMD_UNKNOWN);
    EXPECT_EQ(Parse(R"({"command":["LED_ON"]})"), APP_CMD_UNKNOWN);
}

TEST(CommandParser, ReturnsUnknownForEmptyJsonObject)
{
    EXPECT_EQ(Parse("{}"), APP_CMD_UNKNOWN);
}

// ---------------------------------------------------------------------------
// Input sai định dạng / biên / lỗi
// ---------------------------------------------------------------------------

TEST(CommandParser, ReturnsParseErrorForMalformedJson)
{
    EXPECT_EQ(Parse(R"({"command":"LED_ON")"), APP_CMD_PARSE_ERROR); // thiếu }
    EXPECT_EQ(Parse("not a json"), APP_CMD_PARSE_ERROR);
    EXPECT_EQ(Parse(R"({"command":LED_ON})"), APP_CMD_PARSE_ERROR);  // thiếu quote
}

TEST(CommandParser, ReturnsParseErrorForEmptyInput)
{
    EXPECT_EQ(Parse(""), APP_CMD_PARSE_ERROR);
}

TEST(CommandParser, ReturnsParseErrorForNullPointer)
{
    EXPECT_EQ(command_parser_parse(nullptr, 0), APP_CMD_PARSE_ERROR);
    EXPECT_EQ(command_parser_parse(nullptr, 16), APP_CMD_PARSE_ERROR);
}

TEST(CommandParser, RespectsExplicitLengthOverNulTerminator)
{
    // MQTT payload KHÔNG được đảm bảo null-terminated (aws_iot.c phải tự
    // malloc + gắn '\0'). Parser phải tôn trọng tham số len.
    const char raw[] = "{\"command\":\"LED_ON\"}GARBAGE_BEYOND_LEN";
    const std::size_t json_len = std::strlen("{\"command\":\"LED_ON\"}");
    EXPECT_EQ(command_parser_parse(raw, json_len), APP_CMD_LED_ON);
}

TEST(CommandParser, ReturnsParseErrorForTruncatedPayloadLength)
{
    const char raw[] = "{\"command\":\"LED_ON\"}";
    // Cắt giữa chừng -> JSON không hợp lệ
    EXPECT_EQ(command_parser_parse(raw, 5), APP_CMD_PARSE_ERROR);
}

} // namespace
