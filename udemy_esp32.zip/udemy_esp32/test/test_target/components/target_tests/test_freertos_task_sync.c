/**
 * @file test_freertos_task_sync.c
 * @brief Runtime-only test: task + binary semaphore pattern ma production dang dung.
 *
 * NGUON GOC PATTERN (khong tu tao behavior):
 *   - main/wifi_reset_button.c:46 : wifi_reset_semaphore = xSemaphoreCreateBinary();
 *     ISR give semaphore -> task take semaphore roi gui message vao queue.
 *   - main/wifi_app.c, main/gpio.c, ... : xTaskCreatePinnedToCore(...)
 *
 * Test mo phong pattern nay bang helper task (thay cho ISR) give semaphore,
 * test task take voi timeout huu han. Ket qua helper bao ve test task qua
 * task notification - khong assert cheo task.
 *
 * Khac production: production take voi portMAX_DELAY; test bi cam
 * portMAX_DELAY nen dung timeout huu han.
 */

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "unity.h"

#define TEST_SYNC_TIMEOUT_MS      500
#define HELPER_TASK_STACK_SIZE    2048
#define HELPER_TASK_PRIORITY      5   /* cung muc voi WIFI_APP_TASK_PRIORITY */

typedef struct {
    SemaphoreHandle_t semaphore;      /* semaphore helper se give */
    TaskHandle_t      notify_target;  /* test task nhan notification khi helper xong */
} helper_ctx_t;

/* Helper task: give semaphore mot lan, notify test task roi tu xoa.
 * Khong loop vo han, khong ton tai sau test. */
static void give_semaphore_helper_task(void *pvParameter)
{
    helper_ctx_t *ctx = (helper_ctx_t *)pvParameter;

    xSemaphoreGive(ctx->semaphore);
    xTaskNotifyGive(ctx->notify_target);

    vTaskDelete(NULL);
}

TEST_CASE("task_sync: binary semaphore starts empty and take times out", "[freertos][task]")
{
    SemaphoreHandle_t sem = xSemaphoreCreateBinary();
    TEST_ASSERT_NOT_NULL(sem);

    /* Binary semaphore moi tao chua duoc give -> take phai timeout */
    TEST_ASSERT_EQUAL(pdFALSE, xSemaphoreTake(sem, pdMS_TO_TICKS(100)));

    vSemaphoreDelete(sem);
}

TEST_CASE("task_sync: give then take succeeds within timeout", "[freertos][task]")
{
    SemaphoreHandle_t sem = xSemaphoreCreateBinary();
    TEST_ASSERT_NOT_NULL(sem);

    TEST_ASSERT_EQUAL(pdTRUE, xSemaphoreGive(sem));
    TEST_ASSERT_EQUAL(pdTRUE, xSemaphoreTake(sem, pdMS_TO_TICKS(TEST_SYNC_TIMEOUT_MS)));
    /* Binary semaphore: take lan hai phai timeout (da bi tieu thu) */
    TEST_ASSERT_EQUAL(pdFALSE, xSemaphoreTake(sem, pdMS_TO_TICKS(100)));

    vSemaphoreDelete(sem);
}

TEST_CASE("task_sync: helper task gives semaphore to waiting test task", "[freertos][task]")
{
    SemaphoreHandle_t sem = xSemaphoreCreateBinary();
    TEST_ASSERT_NOT_NULL(sem);

    helper_ctx_t ctx = {
        .semaphore = sem,
        .notify_target = xTaskGetCurrentTaskHandle(),
    };

    /* Xoa notification ton dong (dam bao test lap lai duoc) */
    ulTaskNotifyTake(pdTRUE, 0);

    TaskHandle_t helper = NULL;
    BaseType_t created = xTaskCreate(
        give_semaphore_helper_task, "sem_helper",
        HELPER_TASK_STACK_SIZE, &ctx, HELPER_TASK_PRIORITY, &helper);
    TEST_ASSERT_EQUAL(pdPASS, created);

    /* Take semaphore do helper give - pattern giong wifi_reset_button task */
    TEST_ASSERT_EQUAL(pdTRUE, xSemaphoreTake(sem, pdMS_TO_TICKS(TEST_SYNC_TIMEOUT_MS)));

    /* Cho helper bao hoan tat (co timeout, khong block vo han) */
    TEST_ASSERT_EQUAL(1u, ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(TEST_SYNC_TIMEOUT_MS)));

    /* Helper da vTaskDelete(NULL); nhuong CPU de idle task don dep TCB */
    vTaskDelay(pdMS_TO_TICKS(20));

    vSemaphoreDelete(sem);
}

TEST_CASE("task_sync: semaphore can be deleted and recreated repeatedly", "[freertos][task]")
{
    for (int i = 0; i < 3; i++) {
        SemaphoreHandle_t sem = xSemaphoreCreateBinary();
        TEST_ASSERT_NOT_NULL(sem);
        TEST_ASSERT_EQUAL(pdTRUE, xSemaphoreGive(sem));
        TEST_ASSERT_EQUAL(pdTRUE, xSemaphoreTake(sem, pdMS_TO_TICKS(100)));
        vSemaphoreDelete(sem);
    }
}
