/**
 * @file test_nvs_storage.c
 * @brief On-chip peripheral test: NVS blob storage pattern ma production dang dung.
 *
 * NGUON GOC PATTERN (khong tu tao behavior):
 *   - main/app_nvs.c : nvs_open -> nvs_set_blob("ssid"/"password") -> nvs_commit
 *                      -> nvs_close; doc lai bang nvs_get_blob; xoa bang
 *                      nvs_erase_all + nvs_commit. Namespace production: "stacreds".
 *
 * AN TOAN:
 *   - Test CHI dung namespace rieng "target_test" (quy dinh trong de bai).
 *   - KHONG mo, doc, ghi hay xoa namespace production "stacreds".
 *   - KHONG erase-flash, KHONG xoa toan bo NVS partition.
 *   - Cleanup: nvs_erase_all CHI tren namespace "target_test".
 *
 * LUU Y BLOCKED_BY_COMPONENT_STRUCTURE:
 *   Cac ham app_nvs_save_sta_creds()/app_nvs_load_sta_creds() nam trong main/
 *   va phu thuoc wifi_app_get_wifi_config() (esp_wifi) nen khong the link vao
 *   test firmware nay. Test duoi day kiem tra truc tiep chuoi API NVS ma
 *   app_nvs.c su dung.
 */

#include <string.h>

#include "esp_err.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "unity.h"

/* Namespace danh rieng cho test - KHONG trung "stacreds" cua production */
#define TEST_NVS_NAMESPACE  "target_test"
#define TEST_NVS_KEY_BLOB   "tt_blob"

/* Blob test cung co 32 byte nhu SSID buffer (MAX_SSID_LENGTH=32, wifi_app.h) */
#define TEST_BLOB_SIZE 32

/* Dam bao NVS da init; chap nhan truong hop da duoc init truoc do. */
static void ensure_nvs_ready(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        /* Partition can erase: KHONG tu dong erase trong test de tranh
         * pha production data - fail ro rang de nguoi dung xu ly. */
        TEST_FAIL_MESSAGE("NVS partition can duoc erase/migrate. "
                          "Khong tu dong erase de bao ve production data.");
    }
    TEST_ASSERT_EQUAL(ESP_OK, err);
}

/* Cleanup: xoa MOI key trong namespace test (chi namespace test). */
static void erase_test_namespace(void)
{
    nvs_handle_t handle;
    esp_err_t err = nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle);
    if (err == ESP_OK) {
        nvs_erase_all(handle);   /* chi anh huong namespace "target_test" */
        nvs_commit(handle);
        nvs_close(handle);
    }
}

TEST_CASE("nvs: open dedicated test namespace succeeds", "[nvs]")
{
    ensure_nvs_ready();

    nvs_handle_t handle;
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));
    nvs_close(handle);

    erase_test_namespace();
}

TEST_CASE("nvs: blob write-commit-read returns identical data", "[nvs]")
{
    ensure_nvs_ready();

    uint8_t written[TEST_BLOB_SIZE];
    for (int i = 0; i < TEST_BLOB_SIZE; i++) {
        written[i] = (uint8_t)(i * 3 + 1);
    }

    /* Pattern ghi giong app_nvs_save_sta_creds: open -> set_blob -> commit -> close */
    nvs_handle_t handle;
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_set_blob(handle, TEST_NVS_KEY_BLOB, written, sizeof(written)));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));
    nvs_close(handle);

    /* Pattern doc giong app_nvs_load_sta_creds: open -> get_blob -> close */
    uint8_t readback[TEST_BLOB_SIZE] = {0};
    size_t size = sizeof(readback);
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READONLY, &handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_get_blob(handle, TEST_NVS_KEY_BLOB, readback, &size));
    nvs_close(handle);

    TEST_ASSERT_EQUAL(sizeof(written), size);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(written, readback, TEST_BLOB_SIZE);

    erase_test_namespace();
}

TEST_CASE("nvs: overwriting blob returns latest value", "[nvs]")
{
    ensure_nvs_ready();

    uint8_t first[TEST_BLOB_SIZE];
    uint8_t second[TEST_BLOB_SIZE];
    memset(first, 0xAA, sizeof(first));
    memset(second, 0x55, sizeof(second));

    nvs_handle_t handle;
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_set_blob(handle, TEST_NVS_KEY_BLOB, first, sizeof(first)));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));
    /* Ghi de - pattern giong luu credentials moi */
    TEST_ASSERT_EQUAL(ESP_OK, nvs_set_blob(handle, TEST_NVS_KEY_BLOB, second, sizeof(second)));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));
    nvs_close(handle);

    uint8_t readback[TEST_BLOB_SIZE] = {0};
    size_t size = sizeof(readback);
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READONLY, &handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_get_blob(handle, TEST_NVS_KEY_BLOB, readback, &size));
    nvs_close(handle);

    TEST_ASSERT_EQUAL_UINT8_ARRAY(second, readback, TEST_BLOB_SIZE);

    erase_test_namespace();
}

TEST_CASE("nvs: reading missing key returns ESP_ERR_NVS_NOT_FOUND", "[nvs]")
{
    ensure_nvs_ready();
    erase_test_namespace();   /* dam bao key khong ton tai */

    nvs_handle_t handle;
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));

    uint8_t readback[TEST_BLOB_SIZE];
    size_t size = sizeof(readback);
    /* Pattern loi giong app_nvs_load_sta_creds khi chua co SSID trong flash */
    TEST_ASSERT_EQUAL(ESP_ERR_NVS_NOT_FOUND,
                      nvs_get_blob(handle, TEST_NVS_KEY_BLOB, readback, &size));
    nvs_close(handle);
}

TEST_CASE("nvs: erase_all clears only test namespace keys", "[nvs]")
{
    ensure_nvs_ready();

    uint8_t data[TEST_BLOB_SIZE];
    memset(data, 0x5A, sizeof(data));

    nvs_handle_t handle;
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_set_blob(handle, TEST_NVS_KEY_BLOB, data, sizeof(data)));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));

    /* Pattern xoa giong app_nvs_clear_sta_creds: erase_all -> commit -> close */
    TEST_ASSERT_EQUAL(ESP_OK, nvs_erase_all(handle));
    TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));
    nvs_close(handle);

    /* Key phai bien mat sau erase */
    uint8_t readback[TEST_BLOB_SIZE];
    size_t size = sizeof(readback);
    TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READONLY, &handle));
    TEST_ASSERT_EQUAL(ESP_ERR_NVS_NOT_FOUND,
                      nvs_get_blob(handle, TEST_NVS_KEY_BLOB, readback, &size));
    nvs_close(handle);
}

TEST_CASE("nvs: write-read cycle is repeatable after cleanup", "[nvs]")
{
    ensure_nvs_ready();

    for (int cycle = 0; cycle < 3; cycle++) {
        uint8_t data[TEST_BLOB_SIZE];
        memset(data, (uint8_t)(0x10 + cycle), sizeof(data));

        nvs_handle_t handle;
        TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READWRITE, &handle));
        TEST_ASSERT_EQUAL(ESP_OK, nvs_set_blob(handle, TEST_NVS_KEY_BLOB, data, sizeof(data)));
        TEST_ASSERT_EQUAL(ESP_OK, nvs_commit(handle));
        nvs_close(handle);

        uint8_t readback[TEST_BLOB_SIZE] = {0};
        size_t size = sizeof(readback);
        TEST_ASSERT_EQUAL(ESP_OK, nvs_open(TEST_NVS_NAMESPACE, NVS_READONLY, &handle));
        TEST_ASSERT_EQUAL(ESP_OK, nvs_get_blob(handle, TEST_NVS_KEY_BLOB, readback, &size));
        nvs_close(handle);

        TEST_ASSERT_EQUAL_UINT8_ARRAY(data, readback, TEST_BLOB_SIZE);

        erase_test_namespace();
    }
}
