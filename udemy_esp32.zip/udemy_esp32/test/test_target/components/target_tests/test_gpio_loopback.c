/**
 * @file test_gpio_loopback.c
 * @brief Loopback test: GPIO output -> GPIO input, dung dung cac pin production.
 *
 * NGUON GOC PIN (khong tu doan):
 *   - main/gpio.h : #define GPIO_CONTROL_PIN 18  (production: output)
 *                   #define GPIO_INPUT_PIN   19  (production: input, pulldown)
 *   Ca hai deu la GPIO thuong tren ESP32 (khong phai flash pin 6-11,
 *   khong phai strapping pin 0/2/5/12/15).
 *
 * YEU CAU DAU DAY (xem README):
 *   Jumper noi GPIO18 <-> GPIO19 tren board. KHONG co jumper thi cac test
 *   loopback se FAIL (input pulldown doc duoc 0 khi output high).
 *
 * Cleanup: gpio_reset_pin() cho ca hai pin sau moi test.
 */

#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "unity.h"

/* Pin lay tu main/gpio.h cua production */
#define TEST_GPIO_OUTPUT    18  /* GPIO_CONTROL_PIN */
#define TEST_GPIO_INPUT     19  /* GPIO_INPUT_PIN   */

/* Thoi gian cho tin hieu on dinh sau khi set level (du lon cho GPIO) */
#define SIGNAL_SETTLE_MS    10

/* Cau hinh giong production gpio_task (main/gpio.c):
 * output: reset -> set_direction OUTPUT
 * input : reset -> set_direction INPUT -> pulldown */
static void setup_loopback_pins(void)
{
    TEST_ASSERT_EQUAL(ESP_OK, gpio_reset_pin(TEST_GPIO_OUTPUT));
    TEST_ASSERT_EQUAL(ESP_OK, gpio_set_direction(TEST_GPIO_OUTPUT, GPIO_MODE_OUTPUT));

    TEST_ASSERT_EQUAL(ESP_OK, gpio_reset_pin(TEST_GPIO_INPUT));
    TEST_ASSERT_EQUAL(ESP_OK, gpio_set_direction(TEST_GPIO_INPUT, GPIO_MODE_INPUT));
    TEST_ASSERT_EQUAL(ESP_OK, gpio_set_pull_mode(TEST_GPIO_INPUT, GPIO_PULLDOWN_ONLY));
}

static void cleanup_loopback_pins(void)
{
    gpio_reset_pin(TEST_GPIO_OUTPUT);
    gpio_reset_pin(TEST_GPIO_INPUT);
}

TEST_CASE("gpio: configure output GPIO18 and input GPIO19 succeeds", "[gpio][loopback]")
{
    setup_loopback_pins();
    cleanup_loopback_pins();
}

TEST_CASE("gpio: loopback input reads low when output set low", "[gpio][loopback]")
{
    setup_loopback_pins();

    TEST_ASSERT_EQUAL(ESP_OK, gpio_set_level(TEST_GPIO_OUTPUT, 0));
    vTaskDelay(pdMS_TO_TICKS(SIGNAL_SETTLE_MS));
    TEST_ASSERT_EQUAL(0, gpio_get_level(TEST_GPIO_INPUT));

    cleanup_loopback_pins();
}

TEST_CASE("gpio: loopback input reads high when output set high", "[gpio][loopback]")
{
    setup_loopback_pins();

    TEST_ASSERT_EQUAL(ESP_OK, gpio_set_level(TEST_GPIO_OUTPUT, 1));
    vTaskDelay(pdMS_TO_TICKS(SIGNAL_SETTLE_MS));
    TEST_ASSERT_EQUAL_MESSAGE(1, gpio_get_level(TEST_GPIO_INPUT),
        "Input van la 0: kiem tra jumper GPIO18 -> GPIO19 (xem README)");

    /* Tra output ve 0 truoc khi cleanup */
    gpio_set_level(TEST_GPIO_OUTPUT, 0);
    cleanup_loopback_pins();
}

TEST_CASE("gpio: loopback follows low-high-low transitions", "[gpio][loopback]")
{
    setup_loopback_pins();

    const int sequence[] = { 0, 1, 0, 1, 0 };
    const int steps = sizeof(sequence) / sizeof(sequence[0]);

    for (int i = 0; i < steps; i++) {
        TEST_ASSERT_EQUAL(ESP_OK, gpio_set_level(TEST_GPIO_OUTPUT, sequence[i]));
        vTaskDelay(pdMS_TO_TICKS(SIGNAL_SETTLE_MS));
        TEST_ASSERT_EQUAL_MESSAGE(sequence[i], gpio_get_level(TEST_GPIO_INPUT),
            "Loopback khong bam theo output: kiem tra jumper GPIO18 -> GPIO19");
    }

    cleanup_loopback_pins();
}

TEST_CASE("gpio: pins can be reconfigured repeatedly", "[gpio][loopback]")
{
    for (int i = 0; i < 3; i++) {
        setup_loopback_pins();
        cleanup_loopback_pins();
    }
}
