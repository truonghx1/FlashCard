/**
 * @file test_freertos_queue.c
 * @brief Runtime-only test: FreeRTOS queue pattern ma production dang dung.
 *
 * NGUON GOC PATTERN (khong tu tao behavior):
 *   - main/wifi_app.c:355  : wifi_app_queue_handle = xQueueCreate(3, sizeof(wifi_app_queue_message_t));
 *   - main/http_server.c:483: http_server_monitor_queue_handle = xQueueCreate(3, sizeof(http_server_queue_message_t));
 *   Ca hai message struct production deu chi chua mot enum msgID.
 *
 * LUU Y BLOCKED_BY_COMPONENT_STRUCTURE:
 *   Cac ham production wifi_app_send_message() / http_server_monitor_send_message()
 *   nam trong main/ (khong phai component tai su dung duoc) nen KHONG THE link
 *   vao test firmware nay ma khong sua production build. Test duoi day kiem tra
 *   truc tiep hanh vi FreeRTOS queue voi cung tham so (depth 3, item la enum)
 *   ma production phu thuoc.
 *
 * Khac production: production block bang portMAX_DELAY; test bi cam dung
 * portMAX_DELAY nen moi cho deu co timeout huu han.
 */

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "unity.h"

/* Cung do sau queue voi production (wifi_app.c va http_server.c deu dung 3) */
#define TEST_QUEUE_DEPTH        3
/* Timeout huu han cho moi thao tac send/receive */
#define TEST_QUEUE_TIMEOUT_MS   100

/* Message kieu enum-trong-struct, cung pattern voi wifi_app_queue_message_t
 * va http_server_queue_message_t (mot field msgID kieu enum). */
typedef enum {
    TEST_MSG_A = 0,
    TEST_MSG_B,
    TEST_MSG_C,
    TEST_MSG_D,
} test_msg_id_e;

typedef struct {
    test_msg_id_e msgID;
} test_queue_message_t;

TEST_CASE("queue: create depth-3 queue of enum message succeeds", "[freertos][queue]")
{
    QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
    TEST_ASSERT_NOT_NULL(q);

    vQueueDelete(q);
}

TEST_CASE("queue: sent message is received with same msgID", "[freertos][queue]")
{
    QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
    TEST_ASSERT_NOT_NULL(q);

    test_queue_message_t tx = { .msgID = TEST_MSG_B };
    TEST_ASSERT_EQUAL(pdTRUE, xQueueSend(q, &tx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));

    test_queue_message_t rx = { .msgID = TEST_MSG_A };
    TEST_ASSERT_EQUAL(pdTRUE, xQueueReceive(q, &rx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));
    TEST_ASSERT_EQUAL(TEST_MSG_B, rx.msgID);

    vQueueDelete(q);
}

TEST_CASE("queue: preserves FIFO order for multiple messages", "[freertos][queue]")
{
    QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
    TEST_ASSERT_NOT_NULL(q);

    const test_msg_id_e sequence[TEST_QUEUE_DEPTH] = { TEST_MSG_A, TEST_MSG_C, TEST_MSG_B };

    for (int i = 0; i < TEST_QUEUE_DEPTH; i++) {
        test_queue_message_t tx = { .msgID = sequence[i] };
        TEST_ASSERT_EQUAL(pdTRUE, xQueueSend(q, &tx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));
    }

    for (int i = 0; i < TEST_QUEUE_DEPTH; i++) {
        test_queue_message_t rx;
        TEST_ASSERT_EQUAL(pdTRUE, xQueueReceive(q, &rx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));
        TEST_ASSERT_EQUAL(sequence[i], rx.msgID);
    }

    vQueueDelete(q);
}

TEST_CASE("queue: receive on empty queue times out with pdFALSE", "[freertos][queue]")
{
    QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
    TEST_ASSERT_NOT_NULL(q);

    test_queue_message_t rx;
    TickType_t start = xTaskGetTickCount();
    BaseType_t result = xQueueReceive(q, &rx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS));
    TickType_t elapsed = xTaskGetTickCount() - start;

    TEST_ASSERT_EQUAL(pdFALSE, result);
    /* Phai thuc su cho ~timeout, khong tra ve ngay lap tuc */
    TEST_ASSERT_GREATER_OR_EQUAL(pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS) - 2, elapsed);

    vQueueDelete(q);
}

TEST_CASE("queue: send to full depth-3 queue fails with errQUEUE_FULL", "[freertos][queue]")
{
    QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
    TEST_ASSERT_NOT_NULL(q);

    test_queue_message_t tx = { .msgID = TEST_MSG_D };
    for (int i = 0; i < TEST_QUEUE_DEPTH; i++) {
        TEST_ASSERT_EQUAL(pdTRUE, xQueueSend(q, &tx, 0));
    }
    /* Queue day (depth 3, giong production): message thu 4 phai bi tu choi */
    TEST_ASSERT_EQUAL(errQUEUE_FULL, xQueueSend(q, &tx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));

    vQueueDelete(q);
}

TEST_CASE("queue: can be deleted and recreated repeatedly", "[freertos][queue]")
{
    for (int i = 0; i < 3; i++) {
        QueueHandle_t q = xQueueCreate(TEST_QUEUE_DEPTH, sizeof(test_queue_message_t));
        TEST_ASSERT_NOT_NULL(q);

        test_queue_message_t tx = { .msgID = TEST_MSG_A };
        TEST_ASSERT_EQUAL(pdTRUE, xQueueSend(q, &tx, pdMS_TO_TICKS(TEST_QUEUE_TIMEOUT_MS)));

        vQueueDelete(q);
    }
}
