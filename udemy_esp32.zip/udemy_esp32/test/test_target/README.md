# Giai đoạn 2 — Target-based Unit Test (ESP-IDF Unity)

## Purpose

Firmware test chuyên dụng chạy **trực tiếp trên ESP32 thật**, dùng Unity
Framework tích hợp trong ESP-IDF. Kiểm tra các hành vi phụ thuộc ESP-IDF /
FreeRTOS runtime mà Native Unit Test trên PC (Giai đoạn 1) không kiểm tra
chính xác được: FreeRTOS queue, task + semaphore, NVS flash, GPIO.

> **Trạng thái: NOT_EXECUTED** — test firmware này **chưa được build, chưa
> flash và chưa chạy**. Hiện chưa có board ESP32.

### Ghi chú quan trọng: `BLOCKED_BY_COMPONENT_STRUCTURE`

Tất cả module production (`wifi_app.c`, `http_server.c`, `app_nvs.c`,
`gpio.c`, ...) nằm trực tiếp trong `main/` của production project — **không
phải ESP-IDF component tái sử dụng được**. Test project độc lập này không
thể link các hàm như `wifi_app_send_message()`, `app_nvs_save_sta_creds()`
mà không sửa `main/CMakeLists.txt` (nằm ngoài phạm vi cho phép).

Do đó các test trong firmware này kiểm tra **chính xác các pattern
ESP-IDF/FreeRTOS mà production sử dụng** (trích dẫn nguồn trong từng file
test), chứ không gọi trực tiếp hàm production:

| Test file | Pattern production được kiểm tra | Nguồn |
|---|---|---|
| `test_freertos_queue.c` | `xQueueCreate(3, sizeof(msg))`, send/receive/full/empty | `main/wifi_app.c:355`, `main/http_server.c:483` |
| `test_freertos_task_sync.c` | Binary semaphore give/take + helper task | `main/wifi_reset_button.c:46` |
| `test_nvs_storage.c` | `nvs_open/set_blob/get_blob/commit/erase_all/close` | `main/app_nvs.c` |
| `test_gpio_loopback.c` | Output GPIO18 / input GPIO19 pulldown | `main/gpio.h`, `main/gpio.c` |

**Đề xuất bước tương lai** (KHÔNG thực hiện trong nhiệm vụ này): tách các
module trong `main/` thành ESP-IDF components (`components/wifi_app/`,
`components/app_nvs/`...) để test firmware có thể link và kiểm tra trực
tiếp public API của module production.

## Prerequisites

- ESP-IDF extension trong VS Code hoặc ESP-IDF terminal đã hoạt động
  (project production build bằng ESP-IDF, target `esp32` theo `sdkconfig`).
- ESP-IDF version trùng với version dùng để build production project
  (test component dùng `WHOLE_ARCHIVE` — cần **ESP-IDF ≥ 5.0**, xem
  Troubleshooting nếu dùng 4.x).
- Board ESP32 (target `esp32`).
- Cáp USB data.
- Serial driver (CP210x / CH340 / FTDI tùy board) nếu hệ điều hành yêu cầu.
- 1 jumper wire cho GPIO loopback test (xem Hardware requirements).

## Hardware requirements

- **ESP32 target:** `esp32` (từ `CONFIG_IDF_TARGET="esp32"` trong production `sdkconfig`).
- **Board:** `BOARD_MODEL_REQUIRED` — project không khai báo board model cụ
  thể. Bất kỳ dev board ESP32 nào lộ GPIO18/GPIO19 đều dùng được (ví dụ
  ESP32 DevKitC), nhưng bạn phải tự xác nhận pinout board của mình.
- **Wiring cho `[gpio][loopback]`:**

  ```
  GPIO18 (GPIO_CONTROL_PIN, output) ────jumper──── GPIO19 (GPIO_INPUT_PIN, input pulldown)
  ```

  Không có jumper → các test `[gpio][loopback]` sẽ FAIL (không phải lỗi firmware).
- **NVS:** test ghi vào namespace riêng `target_test`, **không** đụng
  namespace production `stacreds`. Không erase flash.
- **I2C/SPI/UART external peripheral:** không cần — project không có I2C/SPI
  sensor trong production source.
- Các test `[freertos]` và `[nvs]` **không cần đấu dây**.

## Build later

Từ root repository:

```
idf.py -C test/test_target set-target esp32
idf.py -C test/test_target build
```

(Nếu ESP-IDF version không hỗ trợ `-C`, chạy `cd test/test_target` rồi
`idf.py set-target esp32 && idf.py build`.)

## Flash later

```
idf.py -C test/test_target -p <serial-port> flash
```

- Thay `<serial-port>` bằng cổng thực tế trên máy bạn (Windows: `COMx`,
  Linux: `/dev/ttyUSBx` hoặc `/dev/ttyACMx`, macOS: `/dev/cu.*`).
- **Flash sẽ thay thế firmware production hiện có trên board.** Sau khi test
  xong, flash lại production firmware (xem Cleanup).
- **Không chạy `idf.py erase-flash`** — không cần và sẽ xóa NVS production.

## Monitor later

```
idf.py -C test/test_target -p <serial-port> monitor
```

Hoặc gộp:

```
idf.py -C test/test_target -p <serial-port> flash monitor
```

Thoát monitor: `Ctrl+]`.

## Run Unity tests

Sau khi boot, firmware in banner và Unity test menu qua Serial Monitor.
Nhấn Enter nếu chưa thấy menu. Cách chọn test:

- Nhập **số index** để chạy một test (ví dụ `1`).
- Nhập **tên test trong dấu nháy kép** để chạy theo tên
  (ví dụ `"queue: sent message is received with same msgID"`).
- Nhập **tag** để chạy nhóm test: `[freertos]`, `[queue]`, `[task]`,
  `[nvs]`, `[gpio]`, `[loopback]`.
- Nhập `![loopback]` để chạy tất cả **trừ** nhóm cần đấu dây.
- Nhập `*` để chạy tất cả test.

(Các cú pháp trên là của Unity test runner tích hợp trong ESP-IDF —
`unity_run_menu()`.)

## Expected output

Với mỗi test, Unity in:

- Tên test và vị trí file.
- `PASS` khi mọi assertion đạt.
- `FAIL` kèm dòng assertion, expected/actual value khi không đạt
  (ví dụ test loopback fail sẽ in gợi ý kiểm tra jumper).
- Cuối phiên chạy nhóm test: summary dạng `N Tests M Failures K Ignored`.

Không có log mẫu ở đây vì test **chưa từng được chạy** — kết quả thật chỉ có
sau khi bạn flash và chạy trên board.

## Troubleshooting

| Vấn đề | Cách xử lý |
|---|---|
| `IDF_PATH` không tìm thấy | Mở ESP-IDF terminal (đã export môi trường) hoặc chạy `export.ps1`/`export.sh` của ESP-IDF trước. |
| Sai target chip | Chạy lại `idf.py -C test/test_target set-target esp32`. Xóa `test/test_target/build/` nếu đổi target. |
| Undefined reference khi link | Kiểm tra `components/target_tests/CMakeLists.txt` có `REQUIRES unity`, `PRIV_REQUIRES nvs_flash driver`. |
| Không thấy test trong menu | Test component không được link. Cần ESP-IDF ≥ 5.0 cho `WHOLE_ARCHIVE`. Với IDF 4.x: xóa dòng `WHOLE_ARCHIVE` và thêm vào `test/test_target/CMakeLists.txt` (sau `project(...)`): `target_link_libraries(${project_elf} "-Wl,--whole-archive" idf::target_tests "-Wl,--no-whole-archive")`. |
| Serial port busy | Đóng monitor/terminal khác đang giữ port (kể cả Wokwi RFC2217 hoặc test integration của Giai đoạn 3). |
| Permission denied trên serial port (Linux) | Thêm user vào group `dialout`/`uucp` rồi đăng nhập lại. |
| Board không vào download mode | Giữ nút BOOT (GPIO0) khi bắt đầu flash; kiểm tra cáp USB là cáp data. |
| GPIO loopback test FAIL | Kiểm tra jumper GPIO18↔GPIO19 đã cắm chắc; xác nhận pinout board của bạn. |
| NVS test fail `ESP_ERR_NVS_NO_FREE_PAGES` | Partition NVS cần migrate. Test cố ý KHÔNG tự erase để bảo vệ production data — cân nhắc backup rồi tự xử lý partition. |
| NVS test fail do partition configuration | Production dùng `partitions.csv` custom. Nếu test project cần cùng layout, so sánh với partition mặc định của test build. |
| Task/queue timeout bất thường | Chạy lại test đơn lẻ; kiểm tra không có test khác đang giữ resource (mỗi test đã tự cleanup). |
| Watchdog reset | Test đều dùng timeout ngắn (≤500ms) nên hiếm gặp; nếu xảy ra, chạy từng test một để cô lập. |
| I2C device không phản hồi | Không áp dụng — firmware test này không có I2C test (production không dùng I2C). |

## Cleanup

Sau khi chạy test xong:

1. Thoát monitor (`Ctrl+]`).
2. GPIO đã được `gpio_reset_pin()` trong từng test — không cần thao tác thêm.
3. NVS: mỗi test đã tự xóa key trong namespace `target_test`
   (`nvs_erase_all` chỉ trên namespace test). Namespace production
   `stacreds` không bị đụng tới.
4. Tháo jumper GPIO18↔GPIO19 nếu đã cắm.
5. Flash lại production firmware:

   ```
   idf.py -p <serial-port> flash
   ```

   (chạy từ root repository — build production có sẵn.)

## Limitations

- Test **chưa được build**, **chưa được flash**, **chưa được execute**.
- Chưa xác minh trên board thật; board model và wiring có thể cần điều chỉnh
  theo pinout thực tế.
- Không kiểm tra trực tiếp public API của module production
  (`BLOCKED_BY_COMPONENT_STRUCTURE` — xem Purpose).
- Kết quả simulator (Giai đoạn 3 / Wokwi) không thay thế kết quả
  target-based test trên chip thật.
