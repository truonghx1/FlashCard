/**
 * @file test_app_main.c
 * @brief Unity test runner cho Target-based Unit Test (Giai doan 2).
 *
 * Firmware test chuyen dung, KHONG chua production application logic.
 * Sau khi flash, mo Serial Monitor de dieu khien Unity test menu:
 *   - Nhap so index de chay mot test (vi du: 1)
 *   - Nhap ten test trong dau nhay kep de chay theo ten
 *   - Nhap tag de chay nhom test (vi du: [freertos] hoac [nvs])
 *   - Nhap * de chay tat ca test
 *   - Nhap ! truoc tag de loai tru (vi du: ![loopback])
 */

#include <stdio.h>

#include "unity.h"
#include "unity_test_runner.h"

void app_main(void)
{
    printf("\n");
    printf("=============================================\n");
    printf("  udemy_esp32_target_tests\n");
    printf("  Target-based Unit Tests (ESP-IDF Unity)\n");
    printf("=============================================\n");
    printf("Tags: [freertos][queue] [freertos][task] [nvs] [gpio][loopback]\n");
    printf("Luu y: [gpio][loopback] can jumper GPIO18 -> GPIO19 (xem README).\n");
    printf("\n");

    /* Hien thi menu tuong tac qua Serial Monitor.
     * unity_run_menu() khong tu reboot; nguoi dung chon test bang stdin. */
    unity_run_menu();
}
