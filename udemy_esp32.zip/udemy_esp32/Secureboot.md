# 🔐 CẨM NANG SECURE BOOT & CRYPTOGRAPHY (ESP32)

> **Tài liệu toàn diện** về Secure Boot, quy trình ký số, quản lý khóa và triển khai thực tế trên ESP32.
>
> 📅 *Cập nhật: Tháng 1/2026*

---

## 📑 MỤC LỤC

1. [Giới thiệu Secure Boot](#phần-1-giới-thiệu-secure-boot)
2. [Nền tảng Mật mã học](#phần-2-nền-tảng-mật-mã-học-cryptography)
3. [Quy trình Ký số](#phần-3-quy-trình-ký-số-signing-process)
4. [Cơ chế hoạt động (Chain of Trust)](#phần-4-cơ-chế-hoạt-động-chain-of-trust)
5. [Quản lý Khóa](#phần-5-quản-lý-khóa-key-management)
6. [Bảo vệ quá trình OTA](#phần-6-bảo-vệ-quá-trình-ota)
7. [Môi trường Dev vs Production](#phần-7-môi-trường-dev-vs-production)
8. [Thực hành trên ESP32](#phần-8-thực-hành-trên-esp32)
9. [Mô phỏng trên Linux](#phần-9-mô-phỏng-trên-linux)
10. [FAQ - Câu hỏi thường gặp](#phần-10-faq---câu-hỏi-thường-gặp)

---

## PHẦN 1: GIỚI THIỆU SECURE BOOT

### 1.1. Secure Boot là gì?

**Secure Boot** là cơ chế bảo mật đảm bảo chỉ có firmware/software đã được **ký số (digitally signed)** và xác thực mới được phép chạy trên thiết bị.

### 1.2. Mục tiêu bảo vệ

| Mối đe dọa | Mô tả | Secure Boot bảo vệ |
|:---|:---|:---:|
| **Malware Injection** | Hacker cài cắm mã độc vào bootloader/firmware | ✅ |
| **Unauthorized Firmware** | Firmware không được ủy quyền chạy trên thiết bị | ✅ |
| **Rollback Attacks** | Kẻ tấn công hạ cấp về phiên bản cũ có lỗ hổng | ✅ |

### 1.3. Chain of Trust (Chuỗi tin cậy)

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   ROM Code   │────▶│  Bootloader  │────▶│  Application │────▶│   OTA Data   │
│  (Hardware)  │     │   (Signed)   │     │   (Signed)   │     │   (Signed)   │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
   Root of Trust          Verify              Verify              Verify
```

> 💡 **Nguyên tắc:** Mỗi thành phần phải được xác thực bởi thành phần trước đó trong chuỗi.

---

## PHẦN 2: NỀN TẢNG MẬT MÃ HỌC (CRYPTOGRAPHY)

### 2.1. Nguyên lý bảo mật thông tin

Một thuật toán mã hóa tốt phải đáp ứng đầy đủ các nguyên lý sau:

| # | Nguyên lý | Mô tả |
|:---:|:---|:---|
| 1 | **Tính bí mật** | Chỉ người gửi và người nhận mới hiểu được thông tin |
| 2 | **Tính toàn vẹn** | Thông tin không bị thay đổi hoặc thiếu sót |
| 3 | **Tính xác thực** | Chứng minh được danh tính người gửi/nhận |
| 4 | **Không thể chối bỏ** | Người gửi không thể phủ nhận việc đã gửi tin |
| 5 | **Tính nhận dạng** | Xác định quyền hạn của người dùng trong hệ thống |

### 2.2. Phân loại thuật toán mã hóa

```
                    ┌─────────────────────────────────────┐
                    │      THUẬT TOÁN MẬT MÃ HỌC         │
                    └─────────────────────────────────────┘
                                     │
          ┌──────────────────────────┼──────────────────────────┐
          ▼                          ▼                          ▼
   ┌─────────────┐           ┌─────────────┐           ┌─────────────┐
   │  HÀM BĂM   │           │  ĐỐI XỨNG   │           │ BẤT ĐỐI XỨNG│
   │   (Hash)    │           │ (Symmetric) │           │(Asymmetric) │
   └─────────────┘           └─────────────┘           └─────────────┘
         │                         │                         │
         ▼                         ▼                         ▼
     SHA-256                     AES                   RSA / ECDSA
   (Một chiều)               (1 Key chung)          (Cặp Key Pub/Priv)
```

### 2.3. Chi tiết từng thuật toán

#### A. SHA-256 (Secure Hash Algorithm - 256 bit)

> 🔹 Đây **không phải là mã hóa** mà là **hàm băm** - tạo "vân tay kỹ thuật số" của dữ liệu.

| Thuộc tính | Giá trị |
|:---|:---|
| **Loại** | Hàm băm một chiều (One-way Hash) |
| **Input** | Dữ liệu bất kỳ (text, file, firmware...) |
| **Output** | Chuỗi cố định 256-bit (64 ký tự Hex) |
| **Decrypt** | ❌ **KHÔNG THỂ** - Không thể dịch ngược |

**Đặc điểm quan trọng:** Thay đổi 1 bit ở Input → Output thay đổi hoàn toàn.

#### B. AES (Advanced Encryption Standard)

> 🔹 Tiêu chuẩn vàng cho việc **bảo mật nội dung** dữ liệu.

| Thuộc tính | Giá trị |
|:---|:---|
| **Loại** | Mã hóa đối xứng (Symmetric) |
| **Nguyên tắc** | "Chìa khóa nào khóa cửa thì phải dùng chìa đó mở cửa" |
| **Input (Encrypt)** | `Plaintext` + `Secret Key` |
| **Output (Encrypt)** | `Ciphertext` (dữ liệu mã hóa) |
| **Input (Decrypt)** | `Ciphertext` + `Secret Key` |
| **Output (Decrypt)** | `Plaintext` (dữ liệu gốc) |

#### C. RSA (Rivest–Shamir–Adleman)

> 🔹 Thuật toán bất đối xứng lâu đời, có thể dùng để **Mã hóa** HOẶC **Ký số**.

| Thuộc tính | Giá trị |
|:---|:---|
| **Loại** | Mã hóa bất đối xứng (Asymmetric) |
| **Key** | Cặp `Public Key` (công khai) + `Private Key` (bí mật) |

**Hai trường hợp sử dụng:**

| Mục đích | Encrypt/Sign | Decrypt/Verify |
|:---|:---|:---|
| **Bảo mật tin nhắn** | Dùng `Public Key` người nhận | Dùng `Private Key` để giải mã |
| **Ký số (Secure Boot)** | Dùng `Private Key` để ký Hash → `Signature` | Dùng `Public Key` để verify → `True/False` |

#### D. ECDSA (Elliptic Curve Digital Signature Algorithm)

> 🔹 Phiên bản hiện đại của RSA - **nhanh hơn**, **khóa ngắn hơn**, bảo mật tương đương.

| Thuộc tính | Giá trị |
|:---|:---|
| **Loại** | Bất đối xứng - Chuyên dùng để **Ký số** |
| **Input (Sign)** | `Hash của dữ liệu` + `Private Key` |
| **Output (Sign)** | `Signature` (cặp số r, s) |
| **Input (Verify)** | `Hash` + `Signature` + `Public Key` |
| **Output (Verify)** | `Valid` hoặc `Invalid` |

### 2.4. Bảng so sánh tổng hợp

| Thuật toán | Loại | Input | Output | Decrypt/Verify | Mục đích chính |
|:---:|:---:|:---|:---|:---|:---|
| **SHA-256** | Hash | Dữ liệu bất kỳ | Chuỗi 256-bit | ❌ Không thể | Kiểm tra tính toàn vẹn |
| **AES** | Đối xứng | Data + Key A | Ciphertext | Ciphertext + Key A | Giữ bí mật dữ liệu |
| **RSA** | Bất đối xứng | Data + Public Key | Ciphertext | Ciphertext + Private Key | Trao đổi khóa, Ký số |
| **ECDSA** | Bất đối xứng | Hash + Private Key | Signature | Signature + Public Key | Ký số (nhanh, hiệu quả) |

### 2.5. Ứng dụng thực tế trong ESP32 & IoT

| Thuật toán | Ứng dụng | Mô tả |
|:---|:---|:---|
| **SHA-256** | Secure Boot | Tính hash firmware, so sánh với giá trị đã ký |
| **AES-256** | Flash Encryption | Mã hóa toàn bộ code trong Flash |
| **RSA/ECDSA** | Secure Boot, OTA | Ký và xác thực firmware |
| **Kết hợp cả 3** | HTTPS/TLS | Xác thực server + Mã hóa dữ liệu + Đảm bảo toàn vẹn |

> 📚 **Tham khảo:** [Cryptography - Giới thiệu về mật mã học](https://viblo.asia/s/cryptography-p0-gioi-thieu-ve-loat-bai-viet-ve-mat-ma-hoc-obA46emMVKv)

---

## PHẦN 3: QUY TRÌNH KÝ SỐ (SIGNING PROCESS)

### 3.1. Tổng quan quy trình

Biến file `firmware.bin` bình thường thành file an toàn `firmware_signed.bin`.

```
       Input: firmware.bin
              │
              ▼
    ┌───────────────────┐
    │  1. HASHING       │  SHA-256(firmware.bin)
    │     (Băm)         │
    └───────────────────┘
              │
              ▼
        [Hash Digest]  ←── Chuỗi 32 bytes (256-bit)
              │
              │◄────── [Private Key]
              ▼
    ┌───────────────────┐
    │  2. SIGNING       │  RSA/ECDSA Encrypt(Hash, Private Key)
    │     (Ký)          │
    └───────────────────┘
              │
              ▼
      [Signature Block]
              │
              ▼
    ┌───────────────────┐
    │  3. PACKAGING     │  firmware.bin + Signature Block
    │     (Đóng gói)    │
    └───────────────────┘
              │
              ▼
   Output: firmware_signed.bin
```

### 3.2. Chi tiết từng bước

| Bước | Input | Action | Output |
|:---:|:---|:---|:---|
| **1. Hashing** | `firmware.bin` | SHA-256 | `Hash Digest` (32 bytes) |
| **2. Signing** | `Hash` + `Private Key` | RSA/ECDSA | `Signature Block` |
| **3. Packaging** | `firmware.bin` + `Signature` | Gộp file | `firmware_signed.bin` |

---

## PHẦN 4: CƠ CHẾ HOẠT ĐỘNG (CHAIN OF TRUST)

### 4.1. Điều gì xảy ra khi cấp điện cho ESP32?

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         QUY TRÌNH BOOT CỦA ESP32                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ⚡ POWER ON                                                                │
│       │                                                                     │
│       ▼                                                                     │
│  ┌─────────────┐                                                            │
│  │  ROM Code   │ ◄── Phần cứng, không thể thay đổi                          │
│  └─────────────┘                                                            │
│       │                                                                     │
│       ▼                                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  1. Đọc Hash của Public Key từ eFuse                                │    │
│  │  2. Đọc firmware_signed.bin từ Flash                                │    │
│  │  3. Tách: [Nội dung Firmware] + [Chữ ký]                            │    │
│  │  4. Tự tính Hash của Nội dung                                       │    │
│  │  5. Dùng Public Key giải mã Chữ ký → Hash gốc                       │    │
│  │  6. So sánh: Hash tự tính == Hash gốc?                              │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│       │                                                                     │
│       ├──── ✅ KHỚP ────▶ Nhảy vào chạy Firmware (BOOT)                    │
│       │                                                                     │
│       └──── ❌ SAI ─────▶ Treo chip / Khởi động lại (HALT)                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2. Phân biệt FLASH vs BOOT

| Giai đoạn | Thời điểm | Hành động | Secure Boot? |
|:---|:---|:---|:---:|
| **FLASH** | Cắm USB nạp code / OTA | Ghi file vào bộ nhớ Flash | ❌ Chưa can thiệp |
| **BOOT** | Nhấn Reset / Sau khi Flash xong | Kiểm tra chữ ký firmware | ✅ **Làm việc ở đây** |

> 💡 **Kết luận:** Secure Boot là "người bảo vệ cửa ra" (lúc Boot), không phải "gác cửa vào" (lúc Flash). Bạn có thể Flash firmware giả vào chip, nhưng chip sẽ **không bao giờ chịu chạy** nó.

---

## PHẦN 5: QUẢN LÝ KHÓA (KEY MANAGEMENT)

### 5.1. Nguyên tắc sống còn

| Loại Key | Vai trò | Bảo mật | Nếu bị lộ? |
|:---|:---|:---:|:---|
| **Private Key** | Dùng để **KÝ** firmware | 🔴 **Tuyệt mật** | ⚠️ **THẢM HỌA** - Hacker có thể ký malware |
| **Public Key** | Dùng để **KIỂM TRA** | 🟢 Công khai | ✅ Không sao - Chỉ verify được, không ký được |

### 5.2. Vòng đời của Key (Lifecycle)

| Giai đoạn | Hành động | Vị trí Key |
|:---|:---|:---|
| **🏭 Sản xuất (Factory)** | 1. Tạo cặp Key<br>2. Burn Hash của Public Key vào eFuse<br>3. Bật bit Write Protect | Public Key: Nằm chết trong Chip<br>Private Key: Két sắt (HSM/Cloud) |
| **🏠 Vận hành (User)** | Chip chạy bình thường | Chip chỉ chứa Public Key |
| **📡 Cập nhật (OTA)** | 1. Dev ký firmware mới bằng Private Key<br>2. Gửi file đã ký qua mạng<br>3. Chip nhận và tự verify | **Key không bao giờ truyền qua mạng** |

### 5.3. Bảo vệ Private Key

#### A. Giải pháp Phòng thủ (Prevention)

| Giải pháp | Mô tả |
|:---|:---|
| **HSM (Hardware Security Module)** | Lưu key trong thiết bị phần cứng (YubiKey, USB Token). Key không bao giờ thoát ra khỏi thiết bị. |
| **Cloud KMS** | Lưu key trên AWS/Google Cloud. CI/CD gửi hash lên Cloud để ký. |
| **Air-gapped Computer** | Máy tính chuyên ký, không bao giờ nối mạng Internet. |

#### B. Giải pháp Khắc phục (Key Revocation)

Khi Private Key bị lộ, ESP32 Secure Boot V2 có cơ chế **Thu hồi khóa**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      KỊCH BẢN THU HỒI KHÓA (KEY REVOCATION)                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  1. Ban đầu: Nạp Key 1 vào Slot 0, dùng Key 1 để ký                        │
│                          │                                                  │
│                          ▼                                                  │
│  2. Hacker trộm được Key 1 → Bắt đầu tung firmware giả                     │
│                          │                                                  │
│                          ▼                                                  │
│  3. Bạn phát hiện → Tạo Firmware Update đặc biệt                           │
│     (Ký bằng CẢ Key 1 cũ VÀ Key 2 mới)                                     │
│                          │                                                  │
│                          ▼                                                  │
│  4. Firmware này có lệnh: BURN bit "Revoke Key 1" trong eFuse              │
│                          │                                                  │
│                          ▼                                                  │
│  5. Sau update: Chip coi Key 1 là "đồ bỏ đi"                               │
│     → Chỉ chấp nhận firmware ký bằng Key 2                                 │
│     → Firmware giả của hacker (ký Key 1) bị từ chối vĩnh viễn              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

> 📌 **Lưu ý:** ESP32 hỗ trợ lưu tối đa **3 Public Keys** (Slot 0, 1, 2) để dự phòng.

### 5.4. Tại sao Hacker không thể nạp Public Key giả vào chip?

#### Lý do 1: eFuse là "Đường một chiều" (OTP)

```
Trạng thái ban đầu:  0 0 0 0 0 0 0 0
                          │
                          ▼ (Đốt = Burn)
Sau khi nạp Key:     0 0 1 1 0 1 0 1
                          │
                          ▼ (Không thể quay lại!)
Hacker muốn sửa:     ❌ KHÔNG THỂ biến 1 → 0
```

#### Lý do 2: Write Protection (Khóa ghi)

Sau khi nạp Key, nhà máy đốt bit `WR_DIS` → **Mạch ghi bị ngắt vĩnh viễn**.

#### Lý do 3: JTAG & UART bị khóa

| Cổng | Trạng thái sau Secure Boot |
|:---|:---|
| JTAG | ❌ Vô hiệu hóa hoàn toàn |
| UART | ⚠️ Chỉ in log, không nhận lệnh nạp |

> ⚠️ **Ngoại lệ duy nhất:** Tấn công chuỗi cung ứng (Supply Chain Attack) - Hacker nạp key vào chip **TRƯỚC KHI** chip đến tay bạn.

---

## PHẦN 6: BẢO VỆ QUÁ TRÌNH OTA

### 6.1. Ba lớp phòng thủ

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          3 LỚP BẢO VỆ OTA UPDATE                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LỚP 1: TLS/HTTPS - "Chống giả mạo Server"                         │    │
│  │  • ESP32 kiểm tra Certificate của Server                           │    │
│  │  • Sai Certificate → Ngắt kết nối ngay lập tức                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LỚP 2: SIGNED OTA - "Kiểm tra trước khi ghi"                      │    │
│  │  • Firmware hiện tại verify chữ ký firmware mới                    │    │
│  │  • Sai chữ ký → Hủy OTA, không ghi vào Flash                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LỚP 3: PARTITION A/B + ROLLBACK - "Lưới an toàn cuối cùng"        │    │
│  │  • Ghi firmware mới vào ota_1, giữ nguyên ota_0                    │    │
│  │  • Boot thất bại → Tự động quay về ota_0                           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2. Bảng tổng kết chiến lược bảo vệ

| Mối nguy hiểm | Cơ chế bảo vệ | Thời điểm chặn |
|:---|:---|:---|
| Server giả mạo | HTTPS (SSL Certificate Pinning) | Khi bắt đầu kết nối mạng |
| Firmware giả mạo (Server đúng) | Application Level Signature Verification | Trước khi/Trong khi tải về |
| File bị lỗi / Corrupt | Secure Boot Hardware Check | Khi Boot (Khởi động) |
| Hậu quả nếu file lỗi | Partition Rollback (A/B) | Sau khi Boot thất bại → Tự về bản cũ |

---

## PHẦN 7: MÔI TRƯỜNG DEV vs PRODUCTION

### 7.1. So sánh hai môi trường

| Tiêu chí | 🔧 DEV (Development) | 🏭 PRODUCTION |
|:---|:---|:---|
| **Cấu hình** | Mode "Reflashable" | Mode "Release / One-time Flash" |
| **Write Protect** | ❌ Không bật | ✅ Đốt ngay sau khi nạp Key |
| **JTAG/UART Debug** | ✅ Vẫn hoạt động | ❌ Vô hiệu hóa |
| **Nạp lại Key** | ✅ Có thể (tốn slot) | ❌ Không thể |
| **Rủi ro** | ⚠️ Tốn 1 board dev | ⚠️ Không thể hoàn tác |

### 7.2. Quy trình chuyển từ Dev sang Production

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      QUY TRÌNH PRODUCTION DEPLOYMENT                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  1. ❌ VỨT BỎ Key Dev (Không bao giờ dùng cho sản phẩm thật)               │
│                          │                                                  │
│                          ▼                                                  │
│  2. 🔐 Tạo Key Production mới, lưu Private Key trong HSM/Cloud             │
│                          │                                                  │
│                          ▼                                                  │
│  3. 📦 Lấy chip MỚI (Chưa từng dùng Dev)                                   │
│                          │                                                  │
│                          ▼                                                  │
│  4. ⚙️ Cấu hình Release Mode trong menuconfig                               │
│                          │                                                  │
│                          ▼                                                  │
│  5. 🔥 Flash lần đầu (One-time Flash)                                       │
│     → Burn Public Key vào eFuse                                            │
│     → Burn Write Protect                                                   │
│     → Disable JTAG/UART                                                    │
│                          │                                                  │
│                          ▼                                                  │
│  6. ✅ HOÀN TẤT - Chip chỉ chạy firmware của bạn                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## PHẦN 8: THỰC HÀNH TRÊN ESP32

### 8.1. Lộ trình học (Learning Path)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         RECOMMENDED LEARNING PATH                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  📚 Week 1-2: Hiểu lý thuyết                                               │
│  ├── Đọc ESP-IDF Security Guide                                            │
│  └── Học về RSA/ECDSA signing                                              │
│                                                                             │
│  🔧 Week 3-4: Thực hành Development Mode                                   │
│  ├── Enable Secure Boot (không burn eFuse)                                 │
│  ├── Generate keys, sign firmware                                          │
│  └── Test boot flow                                                        │
│                                                                             │
│  🏭 Week 5-6: Production Mode (trên hardware thật)                         │
│  ├── Burn eFuse trên ESP32 test board                                      │
│  ├── Test OTA với signed firmware                                          │
│  └── Test attack scenarios                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 8.2. ESP32 Secure Boot - So sánh V1 vs V2

| Tiêu chí | Secure Boot V1 | Secure Boot V2 |
|:---:|:---|:---|
| **Algorithm** | AES-256 | RSA-3072 hoặc ECDSA |
| **Key storage** | eFuse (256-bit) | eFuse (public key digest) |
| **Revocation** | ❌ Không | ✅ Có (multiple keys) |
| **Recommended** | Legacy | ✅ **Khuyến nghị** |

### 8.3. Các bước implement trên ESP32

```bash
# 1. Cấu hình menuconfig
idf.py menuconfig
# → Security features → Enable Secure Boot V2

# 2. Generate signing key
espsecure.py generate_signing_key --version 2 secure_boot_signing_key.pem

# 3. Build với signing
idf.py build

# 4. Flash (chỉ làm 1 lần - KHÔNG THỂ HOÀN TÁC)
idf.py flash
```

### 8.4. ⚠️ Lưu ý quan trọng

> 🔴 **CẢNH BÁO:**
> - **eFuse là ONE-TIME PROGRAMMABLE** - Một khi enable không thể disable
> - **Backup signing key** - Mất key = Brick thiết bị
> - **Test kỹ trên Development Mode** trước khi chuyển Production

---

## PHẦN 9: MÔ PHỎNG TRÊN LINUX

### 9.1. Script mô phỏng quy trình Secure Boot

```bash
#!/bin/bash
echo "=========================================="
echo "   MÔ PHỎNG SECURE BOOT BẰNG OPENSSL"
echo "=========================================="

# 1. Tạo nội dung Firmware
echo "--- 1. TẠO FIRMWARE GỐC ---"
echo "Firmware Code v1.0" > firmware.bin
cat firmware.bin
echo ""

# 2. Tạo cặp khóa RSA 3072 (Chuẩn ESP32 V2)
echo "--- 2. TẠO CẶP KHÓA (RSA 3072) ---"
openssl genrsa -out private.pem 3072 2>/dev/null
openssl rsa -in private.pem -pubout -out public.pem 2>/dev/null
echo "✅ Đã tạo private.pem và public.pem"
echo ""

# 3. KÝ (Hash -> Sign -> Append)
echo "--- 3. KÝ FIRMWARE (SIGNING) ---"
openssl dgst -sha256 -sign private.pem -out signature.bin firmware.bin
cat firmware.bin signature.bin > firmware_signed_ota.bin
echo "✅ Đã tạo file OTA: firmware_signed_ota.bin"
echo ""

# 4. VERIFY - Giả lập chip xác thực
echo "--- 4. MÔ PHỎNG BOOT (VERIFYING) - SUCCESS CASE ---"
echo "Đang kiểm tra firmware gốc..."
openssl dgst -sha256 -verify public.pem -signature signature.bin firmware.bin
echo ""

# 5. Mô phỏng tấn công
echo "--- 5. MÔ PHỎNG TẤN CÔNG (VERIFYING) - FAILURE CASE ---"
echo "Hacker đang chỉnh sửa firmware..."
echo "Malware Code" >> firmware.bin
echo "Đang kiểm tra firmware bị hack..."
openssl dgst -sha256 -verify public.pem -signature signature.bin firmware.bin
echo ""

# Dọn dẹp
rm -f firmware.bin signature.bin private.pem public.pem firmware_signed_ota.bin
echo "=========================================="
echo "   KẾT THÚC MÔ PHỎNG"
echo "=========================================="
```

### 9.2. Kết quả mong đợi

| Bước | Kết quả |
|:---|:---|
| Bước 4 (Firmware gốc) | `Verified OK` ✅ |
| Bước 5 (Firmware bị hack) | `Verification Failure` ❌ |

---

## PHẦN 10: FAQ - CÂU HỎI THƯỜNG GẶP

### Q1: Hacker có thể nạp Public Key của hắn vào chip không?

**Trả lời: KHÔNG.**

Vì eFuse là bộ nhớ "đốt một lần" (OTP) và được bảo vệ bởi bit Write Protect:
- ❌ Hắn không thể sửa bit 1 thành 0
- ❌ Hắn không thể ghi thêm bit 1 (mạch ghi đã bị ngắt)
- ⚠️ Trừ khi: Tấn công chuỗi cung ứng (mua chip trắng, nạp key rồi bán lại)

---

### Q2: Nếu lộ Private Key thì sao?

**Trả lời: THẢM HỌA.** Hacker có thể tạo firmware giả.

**Giải pháp:** Dùng tính năng **Key Revocation** của ESP32:
1. Tạo firmware mới, ký bằng Key mới (Key 2)
2. Firmware này có lệnh đốt bỏ Key 1 trong eFuse
3. Khi người dùng update, chip hủy tin tưởng Key 1, chuyển sang Key 2

---

### Q3: Có bao nhiêu Key có thể lưu trên board?

**Trả lời:** ESP32 hỗ trợ lưu tối đa **3 Public Keys** (Slot 0, 1, 2) để dự phòng cho việc xoay vòng hoặc thu hồi khóa.

---

### Q4: Từ 1 Private Key có thể tạo nhiều Public Key không?

**Trả lời: KHÔNG.** Đây là mối quan hệ 1-1 (Toán học). Một Private Key chỉ sinh ra được **duy nhất 1 Public Key** tương ứng.

---

### Q5: Public Key nạp vào chip khi nào?

**Trả lời:** Nó được nạp **duy nhất một lần** tại **nhà máy (Factory)**, trước khi thiết bị được bán ra.

**Tuyệt đối KHÔNG gửi Public Key qua OTA.** Vì nếu cho phép nạp lại, hacker có thể nạp key của hắn vào.

---

## 📚 TÀI LIỆU THAM KHẢO

1. **ESP-IDF Security Guide:** https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/
2. **Secure Boot V2:** https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/secure-boot-v2.html
3. **Flash Encryption:** https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/flash-encryption.html
4. **Cryptography - Viblo:** https://viblo.asia/s/cryptography-p0-gioi-thieu-ve-loat-bai-viet-ve-mat-ma-hoc-obA46emMVKv

---

> 📝 **Ghi chú:** Tài liệu này được tổng hợp cho mục đích học tập và nghiên cứu. Luôn tham khảo tài liệu chính thức của Espressif khi triển khai sản phẩm thực tế.
