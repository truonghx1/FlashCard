Bạn là kỹ sư Integration Test cho dự án ESP32 sử dụng ESP-IDF.

Hiện tại tôi không có board ESP32 thật.

Nhiệm vụ của bạn là chuẩn bị Giai đoạn 3: Integration Test bằng Wokwi Simulator chạy trong VS Code và Python test script giao tiếp với firmware qua Serial RFC2217.

Chỉ tạo cấu hình, test script và tài liệu hướng dẫn. Tôi sẽ tự build firmware, khởi động Wokwi và chạy test sau.

Không được tuyên bố test đã chạy hoặc đã PASS.

# 1. Mục tiêu

Chuẩn bị môi trường Integration Test để kiểm tra luồng tích hợp của ứng dụng, ví dụ:

Sensor mô phỏng
-> ESP-IDF driver
-> FreeRTOS Queue
-> Processing Task
-> Application output
-> Serial log hoặc Serial response

Nếu project có Wi-Fi, MQTT hoặc HTTP thì phân tích và chuẩn bị test phù hợp, nhưng ưu tiên luồng Serial RFC2217 vì hiện tại không có phần cứng thật.

Integration Test phải kiểm tra hành vi qua interface công khai của firmware, không kiểm tra trực tiếp hàm nội bộ.

# 2. Công nghệ bắt buộc

Sử dụng:

- ESP-IDF
- Wokwi Simulator for VS Code
- `wokwi.toml`
- `diagram.json`
- Python 3
- pytest
- pyserial
- RFC2217 Serial forwarding
- Cổng mặc định 4000
- Baud rate mặc định 115200

Python phải kết nối bằng URL:

rfc2217://localhost:4000

Không sử dụng:

- Robot Framework
- PlatformIO
- Arduino Framework
- Board ESP32 thật
- COM port hoặc `/dev/ttyUSB*` cố định
- Public MQTT broker
- Production server
- Credential thật
- Docker
- GitHub Actions trong nhiệm vụ này

# 3. Phạm vi thay đổi

Được phép đọc toàn bộ repository để phân tích.

Chỉ được phép tạo hoặc chỉnh sửa:

- `wokwi.toml`
- `diagram.json`
- `test/integration/**`

Không được chỉnh sửa:

- `main/**`
- `components/**`
- `test/test_desktop/**`
- `test/test_target/**`
- Root `CMakeLists.txt`
- `sdkconfig`
- `sdkconfig.defaults`
- Partition table
- Bootloader configuration
- `.github/**`
- Production source code

Không được xóa, đổi tên hoặc format lại file production.

Nếu `test/integration/` chưa tồn tại, tạo cấu trúc:

test/integration/
├── README.md
├── requirements.txt
├── pytest.ini
├── conftest.py
├── scripts/
│   └── wait_for_simulator.py
└── tests/
    └── test_serial_integration.py

Chỉ tạo thêm file trong `test/integration/` nếu thực sự cần thiết.

# 4. Khảo sát project

Trước khi tạo file, đọc và phân tích:

- Root `CMakeLists.txt`
- `main/CMakeLists.txt`
- Source trong `main/`
- Header trong `main/`
- Các component liên quan
- `sdkconfig` nếu tồn tại
- Log được ghi bằng `ESP_LOGI`, `ESP_LOGW`, `ESP_LOGE`
- UART input hoặc command interface
- FreeRTOS task
- FreeRTOS queue
- Sensor driver
- Wi-Fi, MQTT hoặc HTTP flow
- ESP-IDF target chip
- Tên ELF output dự kiến
- Các GPIO đang sử dụng

Xác định một luồng tích hợp thực tế đang tồn tại trong code.

Không được tưởng tượng command, log message, sensor hoặc protocol không tồn tại trong source.

Nếu source không có interface điều khiển được từ Serial, vẫn tạo Wokwi configuration và bộ khung Python để quan sát boot log, nhưng đánh dấu functional integration test là `BLOCKED_BY_INTERFACE`.

Không chỉnh sửa production code để thêm test hook.

# 5. Test plan

Trước khi tạo file, trình bày test plan ngắn gồm:

- Luồng tích hợp được chọn
- Module tham gia
- Input
- Output quan sát được
- FreeRTOS task hoặc queue liên quan
- Thiết bị mô phỏng cần có trong `diagram.json`
- GPIO mapping lấy từ source
- Serial command nếu source thực sự hỗ trợ
- Serial log hoặc response mong đợi
- Timeout
- Cleanup
- File sẽ tạo
- Giới hạn của mô phỏng

Sau test plan, tiếp tục tạo file mà không hỏi tôi xác nhận.

# 6. Cấu hình Wokwi

Tạo `wokwi.toml` tại root repository.

Cấu hình cơ bản:

[wokwi]
version = 1
firmware = "build/flasher_args.json"
elf = "build/<actual-project-name>.elf"
rfc2217ServerPort = 4000

Yêu cầu:

- Xác định đúng tên ELF từ cấu hình project.
- Không tự đoán tên ELF nếu có thể đọc từ root `CMakeLists.txt`.
- Dùng dấu `/`, không dùng `\`.
- Không trỏ đến firmware Arduino.
- Không trỏ đến file không thuộc ESP-IDF build output.
- Có thể thêm `gdbServerPort` chỉ khi thực sự cần cho debug.
- Không thêm cấu hình network forwarding hoặc credential nếu chưa cần.

ESP-IDF sẽ tạo `build/flasher_args.json` sau khi người dùng chạy:

idf.py build

Không chạy build trong nhiệm vụ này.

# 7. Tạo diagram.json

Tạo `diagram.json` tại root repository.

Yêu cầu:

- Chọn đúng board ESP32 tương thích với target chip trong project.
- Chỉ thêm linh kiện mô phỏng cần thiết cho flow đã tìm thấy.
- GPIO wiring phải dựa trên source hoặc cấu hình project.
- Không tự đoán GPIO.
- Nếu GPIO chưa xác định được, để board-only diagram và ghi rõ giới hạn trong README.
- Không tạo sensor không được production code sử dụng.
- Không thay đổi production source để phù hợp với diagram.
- JSON phải hợp lệ.
- Các part ID phải rõ ràng và ổn định.

Nếu chưa xác định được ngoại vi cần mô phỏng, tạo diagram tối thiểu chỉ chứa board ESP32 tương ứng.

# 8. Python environment

Tạo `test/integration/requirements.txt` với dependency tối thiểu và pin version hợp lý:

- pytest
- pyserial

Không thêm package không sử dụng.

Tạo `test/integration/pytest.ini` để:

- Chỉ tìm test trong `tests/`
- Dùng tên file `test_*.py`
- Hiển thị summary rõ ràng
- Đăng ký marker `simulation`
- Đăng ký marker `serial`
- Không che giấu output lỗi quan trọng

# 9. Serial fixture

Tạo `test/integration/conftest.py`.

Fixture phải:

- Đọc URL từ environment variable `ESP32_SERIAL_URL`.
- Default là `rfc2217://localhost:4000`.
- Đọc baud rate từ `ESP32_BAUD_RATE`.
- Default là `115200`.
- Đọc timeout từ `ESP32_TEST_TIMEOUT`.
- Có default hợp lý, ví dụ 15 giây.
- Kết nối bằng `serial.serial_for_url()`.
- Không hardcode COM port.
- Không hardcode Linux serial device.
- Đóng serial connection trong `finally`.
- Reset input buffer khi phù hợp.
- Báo lỗi rõ ràng nếu Wokwi chưa chạy.
- Không retry vô hạn.
- Không dùng `time.sleep()` dài và tùy ý.
- Sử dụng deadline dựa trên `time.monotonic()`.

Nếu simulator chưa chạy, test phải fail hoặc skip với thông báo rõ ràng:

Wokwi simulator is not available at rfc2217://localhost:4000

Không được biến lỗi kết nối thành PASS.

# 10. Wait-for-simulator script

Tạo:

test/integration/scripts/wait_for_simulator.py

Script phải:

- Nhận URL, baud rate và timeout từ command line.
- Default URL là `rfc2217://localhost:4000`.
- Default baud rate là `115200`.
- Có timeout hữu hạn.
- Return exit code 0 khi kết nối thành công.
- Return non-zero khi timeout hoặc kết nối thất bại.
- In thông báo ngắn, rõ ràng.
- Luôn đóng connection.
- Không phụ thuộc shell riêng của Windows hoặc Linux.

Ví dụ cách sử dụng dự kiến:

python test/integration/scripts/wait_for_simulator.py \
  --url rfc2217://localhost:4000 \
  --baud-rate 115200 \
  --timeout 30

# 11. Integration tests

Tạo:

test/integration/tests/test_serial_integration.py

Ưu tiên các test theo thứ tự:

## Test 1: Simulator serial availability

Kiểm tra Python có thể kết nối tới RFC2217 port.

Không xem kết nối thành công là đủ để chứng minh firmware hoạt động.

## Test 2: Firmware boot evidence

Đọc Serial theo deadline và tìm boot/application log thực sự tồn tại trong source hoặc cấu hình project.

Không dùng một chuỗi expected tùy ý.

Không phụ thuộc hoàn toàn vào timestamp hoặc thứ tự log không ổn định.

Khi fail, in phần Serial output đã thu được để debug.

## Test 3: Application readiness

Tìm log hoặc response chứng minh application task đã được khởi tạo.

Expected pattern phải lấy từ production source.

Nếu không có application-ready signal đáng tin cậy, không tạo assertion giả. Đánh dấu test đó là skip với lý do rõ ràng.

## Test 4: End-to-end serial flow

Chỉ tạo test này nếu firmware thực sự có command input qua UART/console.

Quy trình:

1. Gửi command hợp lệ.
2. Chờ response bằng deadline.
3. Xác nhận response đúng.
4. Gửi input sai nếu protocol hỗ trợ.
5. Xác nhận firmware trả lỗi hoặc không crash.
6. Không dựa trên delay cố định.
7. Không giả định command không có trong source.

## Test 5: Sensor-to-task flow

Chỉ tạo nếu Wokwi có linh kiện phù hợp và production source thực sự đọc sensor đó.

Kiểm tra qua output công khai như Serial log, MQTT message hoặc HTTP response.

Không gọi trực tiếp hàm nội bộ.

Nếu chưa thể tự động thay đổi sensor input từ Python, ghi test design vào README nhưng không tạo test giả luôn PASS.

## Test 6: Network flow

Chỉ tạo nếu project đã có Wi-Fi/MQTT/HTTP logic và có thể cấu hình an toàn cho môi trường local/simulation.

Không sử dụng:

- Broker production
- Public broker
- API production
- Credential thật

Nếu cần credential hoặc local service chưa có, chỉ mô tả prerequisite và đánh dấu test là chưa thực thi.

# 12. Helper functions

Có thể tạo helper bên trong `test/integration/` để:

- Đọc serial đến deadline
- Chờ regex pattern
- Gửi command có line ending đúng
- Thu thập diagnostic output
- Chuẩn hóa CRLF/LF

Helper phải:

- Có timeout hữu hạn
- Không nuốt exception
- Không loop vô hạn
- Không mất phần log dùng để chẩn đoán
- Hoạt động trên Windows, Linux và macOS

# 13. README

Tạo `test/integration/README.md`.

README phải hướng dẫn đúng thứ tự:

## Prerequisites

- ESP-IDF extension/toolchain đã hoạt động trong VS Code
- Python 3
- Wokwi for VS Code extension
- Wokwi license nếu extension yêu cầu
- Python virtual environment

## Install Python dependencies

Windows PowerShell:

python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r test/integration/requirements.txt

Linux/macOS:

python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r test/integration/requirements.txt

## Build firmware later

idf.py set-target <actual-target>
idf.py build

Ghi rõ rằng lệnh build sẽ tạo:

build/flasher_args.json

và ELF tương ứng.

## Start simulator later

Trong VS Code:

1. Mở Command Palette bằng F1.
2. Chạy `Wokwi: Start Simulator`.
3. Giữ tab simulator đang hiển thị.
4. Đợi firmware boot.

## Check RFC2217 connection

python test/integration/scripts/wait_for_simulator.py

## Run tests

python -m pytest test/integration/tests -v

## Environment overrides

Ví dụ PowerShell:

$env:ESP32_SERIAL_URL="rfc2217://localhost:4000"
$env:ESP32_BAUD_RATE="115200"
$env:ESP32_TEST_TIMEOUT="20"

Ví dụ Linux/macOS:

export ESP32_SERIAL_URL="rfc2217://localhost:4000"
export ESP32_BAUD_RATE="115200"
export ESP32_TEST_TIMEOUT="20"

## Troubleshooting

Bao gồm:

- `build/flasher_args.json` chưa tồn tại
- ELF path sai
- Wokwi chưa được start
- Port 4000 đang được dùng
- Python không kết nối được RFC2217
- Không nhận được boot log
- Simulator tab bị pause hoặc không hiển thị
- Baud rate không khớp
- Expected log đã thay đổi
- Target chip không khớp diagram

## Limitations

Ghi rõ:

- Simulator không thay thế hoàn toàn phần cứng thật.
- Timing, RF, điện áp, nhiễu, hiệu năng và peripheral behavior có thể khác board thật.
- Kết quả simulation phải được xác minh lại trên ESP32 thật trước khi release.
- Các test được tạo trong nhiệm vụ này chưa được build hoặc execute.

# 14. Không build và không chạy

Trong nhiệm vụ này tuyệt đối không:

- Chạy `idf.py build`
- Chạy `idf.py flash`
- Chạy Wokwi
- Chạy pytest
- Kết nối đến RFC2217 port
- Cài package
- Khởi động MQTT broker
- Gọi HTTP service
- Tuyên bố PASS
- Tuyên bố BUILD_PASS

Tôi sẽ tự build và chạy sau.

Trạng thái cuối cùng bắt buộc là:

NOT_EXECUTED

Nếu không thể tạo cấu hình do thiếu thông tin quan trọng, dùng:

BLOCKED

# 15. Kiểm tra trước khi kết thúc

Trước khi kết thúc:

1. Validate cú pháp `wokwi.toml`.
2. Validate JSON của `diagram.json`.
3. Kiểm tra cú pháp Python mà không execute integration tests.
4. Kiểm tra import path của test.
5. Kiểm tra đường dẫn firmware và ELF dựa trên project.
6. Kiểm tra không có credential.
7. Kiểm tra không có COM port hoặc `/dev/ttyUSB*` hardcode.
8. Kiểm tra mọi loop đều có timeout.
9. Kiểm tra mọi serial connection đều được đóng.
10. Kiểm tra không có production file bị thay đổi.
11. Nếu Copilot vô tình sửa file ngoài phạm vi, hoàn tác riêng thay đổi đó.
12. Không hoàn tác thay đổi có sẵn của người dùng.
13. Không commit và không push Git.

# 16. Báo cáo cuối cùng

Trả về báo cáo ngắn đúng cấu trúc:

## Integration flow

- Input
- Các module tham gia
- Output quan sát được

## Wokwi configuration

- ESP32 target
- Firmware path
- ELF path
- Simulated components
- RFC2217 port

## Files created

Liệt kê tất cả file đã tạo hoặc chỉnh sửa.

## Prepared tests

Liệt kê từng integration test và điều kiện thực thi.

## Commands for me to run later

Liệt kê đúng thứ tự:

1. Cài dependency
2. Build ESP-IDF
3. Start Wokwi trong VS Code
4. Kiểm tra RFC2217
5. Chạy pytest

## Status

NOT_EXECUTED hoặc BLOCKED

## Limitations

Các giới hạn của simulator và những phần chưa thể xác minh.

## Next step

Chỉ đưa ra một bước tiếp theo cụ thể.

Bắt đầu bằng việc khảo sát repository và tìm một integration flow thực sự tồn tại trong source. Không tự tạo protocol, command, log hoặc expected result không có trong project.
``