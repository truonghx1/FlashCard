# 📚 Hướng Dẫn Chi Tiết: ESP32 WiFi Application

## 🎯 Mục Tiêu Của Project
Project này tạo một **ESP32 Access Point (AP)** - tức ESP32 sẽ phát WiFi riêng, cho phép các thiết bị khác (điện thoại, laptop) kết nối vào nó.

---

## 📊 LƯU ĐỒ TỔNG QUAN

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ESP32 BOOT                                        │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         app_main() [main.c]                                  │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. nvs_flash_init() - Khởi tạo bộ nhớ NVS (Non-Volatile Storage)   │   │
│  │  2. wifi_app_start() - Bắt đầu ứng dụng WiFi                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     wifi_app_start() [wifi_app.c]                            │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. rgb_led_wifi_app_started() - Bật LED báo hiệu app đã start       │   │
│  │  2. Tạo Message Queue (hàng đợi tin nhắn)                            │   │
│  │  3. Tạo Task "wifi_app_task" chạy trên Core 0                        │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     wifi_app_task() [wifi_app.c]                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. wifi_app_event_handle_init() - Đăng ký event handler             │   │
│  │  2. wifi_app_default_wifi_init() - Khởi tạo TCP/IP & WiFi driver     │   │
│  │  3. wifi_app_soft_ap_config() - Cấu hình Access Point                │   │
│  │  4. esp_wifi_start() - Bật WiFi                                      │   │
│  │  5. Gửi message START_HTTP_SERVER vào queue                          │   │
│  │  6. Vòng lặp VÔ TẬN: Chờ và xử lý message từ queue                  │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     MESSAGE QUEUE LOOP (Vòng lặp chính)                      │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                                                                       │   │
│  │    ┌─────────────────────┐      ┌─────────────────────────────────┐  │   │
│  │    │ MSG_START_HTTP      │ ──▶  │ Bật LED màu: HTTP server started│  │   │
│  │    └─────────────────────┘      └─────────────────────────────────┘  │   │
│  │                                                                       │   │
│  │    ┌─────────────────────┐      ┌─────────────────────────────────┐  │   │
│  │    │ MSG_CONNECTING      │ ──▶  │ (Đang kết nối - chưa implement) │  │   │
│  │    └─────────────────────┘      └─────────────────────────────────┘  │   │
│  │                                                                       │   │
│  │    ┌─────────────────────┐      ┌─────────────────────────────────┐  │   │
│  │    │ MSG_STA_GOT_IP      │ ──▶  │ Bật LED màu: WiFi connected     │  │   │
│  │    └─────────────────────┘      └─────────────────────────────────┘  │   │
│  │                                                                       │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📁 CẤU TRÚC FILE VÀ CHỨC NĂNG

```
udemy_esp32/main/
├── main.c          → Điểm khởi đầu (entry point)
├── wifi_app.c      → Logic chính của WiFi application
├── wifi_app.h      → Khai báo, định nghĩa macro, struct
├── rgb_led.c       → Điều khiển LED RGB
├── rgb_led.h       → Khai báo LED functions
└── task_common.h   → Cấu hình task (stack size, priority)
```

---

## 🔧 GIẢI THÍCH CHI TIẾT TỪNG PHẦN

### 1️⃣ main.c - Điểm Bắt Đầu

```c
void app_main(void) {
    // Bước 1: Khởi tạo NVS (Non-Volatile Storage)
    esp_err_t ret = nvs_flash_init();
    
    // Bước 2: Kiểm tra lỗi và xử lý
    if(ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND){
        ESP_ERROR_CHECK(nvs_flash_erase());  // Xóa NVS nếu lỗi
        ret = nvs_flash_init();              // Khởi tạo lại
    }
    
    // Bước 3: Bắt đầu WiFi app
    wifi_app_start();
}
```

**🔑 Khái niệm quan trọng:**
- **NVS (Non-Volatile Storage)**: Bộ nhớ Flash để lưu dữ liệu khi tắt nguồn (như SSID, password WiFi đã kết nối trước đó)
- **app_main()**: Hàm đặc biệt - ESP-IDF tự động gọi khi boot

---

### 2️⃣ wifi_app.h - Cấu Hình WiFi Access Point

```c
// ═══════════════════════════════════════════════════════════════════
// CẤU HÌNH ACCESS POINT (AP) - ESP32 sẽ phát WiFi với thông tin này
// ═══════════════════════════════════════════════════════════════════

#define WIFI_APP_SSID           "ESP32_APP"      // Tên WiFi sẽ hiển thị
#define WIFI_APP_PASSWORD       "password"       // Mật khẩu để kết nối
#define WIFI_AP_CHANNEL         1                // Kênh WiFi (1-13)
#define WIFI_AP_SSID_HIDDEN     0                // 0 = hiển thị, 1 = ẩn
#define WIFI_AP_CONNECTION      5                // Tối đa 5 thiết bị kết nối
#define WIFI_AP_BEACON_INTERVAL 100              // Beacon mỗi 100ms

// ═══════════════════════════════════════════════════════════════════
// CẤU HÌNH IP ADDRESS
// ═══════════════════════════════════════════════════════════════════

#define WIFI_AP_IP              "192.168.0.1"    // IP của ESP32
#define WIFI_AP_GATEWAY         "192.168.0.1"    // Gateway (= IP vì ESP32 là router)
#define WIFI_AP_NETMASK         "255.255.255.0"  // Subnet mask

// ═══════════════════════════════════════════════════════════════════
// CẤU HÌNH KHÁC
// ═══════════════════════════════════════════════════════════════════

#define WIFI_AP_BANDWIDTH       WIFI_BW_HT20     // Băng thông 20MHz (tiết kiệm điện)
#define WIFI_STA_POWER_SAVE     WIFI_PS_NONE     // Không tiết kiệm điện
#define MAX_SSID_LENGTH         32               // Độ dài tối đa SSID (chuẩn IEEE)
#define MAX_PASSWORD_LENGTH     64               // Độ dài tối đa password
#define MAX_CONNECTION_RETRIES  5                // Số lần thử kết nối lại
```

**📌 Giải thích các cấu hình:**

| Macro | Giá trị | Ý nghĩa |
|-------|---------|---------|
| `WIFI_AP_CHANNEL` | 1 | Kênh WiFi 2.4GHz (1-13 ở VN) |
| `WIFI_AP_BEACON_INTERVAL` | 100ms | Tần suất phát tín hiệu "tôi đây" |
| `WIFI_BW_HT20` | 20MHz | Băng thông hẹp (ổn định, ít nhiễu) |
| `WIFI_BW_HT40` | 40MHz | Băng thông rộng (tốc độ cao hơn) |

---

### 3️⃣ Message Queue - Cơ Chế Giao Tiếp Giữa Các Task

```
┌─────────────────────────────────────────────────────────────────────┐
│                     MESSAGE QUEUE PATTERN                            │
│                                                                      │
│   ┌──────────┐     ┌─────────────────┐     ┌──────────────────┐    │
│   │ Producer │ ──▶ │  Message Queue  │ ──▶ │    Consumer      │    │
│   │ (Gửi)    │     │  (Hàng đợi)     │     │    (Nhận & xử lý)│    │
│   └──────────┘     └─────────────────┘     └──────────────────────┘    │
│                                                                      │
│   Ví dụ:                                                             │
│   - Event WiFi connected → Gửi MSG_STA_GOT_IP vào queue             │
│   - wifi_app_task() nhận message → Bật LED xanh                     │
└─────────────────────────────────────────────────────────────────────┘
```

**Các loại Message được định nghĩa:**
```c
typedef enum wifi_app_message {
    WIFI_APP_MSG_START_HTTP_SERVER = 0,     // HTTP server đã start
    WIFI_APP_MSG_CONNECTING_FROM_HTTP_SERVER, // Đang kết nối từ HTTP
    WIFI_APP_MSG_STA_CONNECTED_GOT_IP       // Đã kết nối và có IP
} wifi_app_message_e;
```

---

### 4️⃣ wifi_app.c - Luồng Chạy Chi Tiết

#### 4.1 wifi_app_start() - Hàm khởi động

```c
void wifi_app_start(void) {
    // 1. Bật LED báo hiệu app đã khởi động
    rgb_led_wifi_app_started();
    
    // 2. Tắt log WiFi (giảm nhiễu serial)
    esp_log_level_set("wifi", ESP_LOG_NONE);
    
    // 3. Tạo Queue chứa 3 message
    wifi_app_queue_handle = xQueueCreate(3, sizeof(wifi_app_queue_message_t));
    
    // 4. Tạo Task chạy trên Core 0
    xTaskCreatePinnedToCore(
        &wifi_app_task,           // Pointer đến function
        "wifi_app_task",          // Tên task (debug)
        WIFI_APP_TASK_STACK_SIZE, // Stack = 4096 bytes
        NULL,                     // Tham số truyền vào
        WIFI_APP_TASK_PRIORITY,   // Priority = 5
        NULL,                     // Handle (không cần)
        WIFI_APP_TASK_CORE_ID     // Chạy trên Core 0
    );
}
```

**🔑 FreeRTOS Concepts:**
- **Task**: Như một thread, chạy song song
- **Queue**: Hàng đợi message, thread-safe
- **Core**: ESP32 có 2 core (0 và 1)

#### 4.2 wifi_app_task() - Task chính

```
┌─────────────────────────────────────────────────────────────────────┐
│                     wifi_app_task() FLOW                             │
└─────────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┴─────────────────────┐
        ▼                                           │
┌───────────────────┐                               │
│ INITIALIZATION    │                               │
├───────────────────┤                               │
│ 1. Event Handler  │ ◀── Đăng ký lắng nghe events │
│ 2. TCP/IP Stack   │ ◀── esp_netif_init()         │
│ 3. WiFi Driver    │ ◀── esp_wifi_init()          │
│ 4. AP Config      │ ◀── Cấu hình Access Point    │
│ 5. WiFi Start     │ ◀── esp_wifi_start()         │
└───────────────────┘                               │
        │                                           │
        ▼                                           │
┌───────────────────┐                               │
│ SEND FIRST MSG    │                               │
│ START_HTTP_SERVER │                               │
└───────────────────┘                               │
        │                                           │
        ▼                                           │
┌───────────────────┐                               │
│  INFINITE LOOP    │ ◀───────────────────────────┐│
│  for(;;) {        │                              ││
│    xQueueReceive()│ ◀── Chờ message từ queue    ││
│    switch(msgID)  │ ◀── Xử lý theo loại message ││
│  }                │                              ││
└───────────────────┘ ─────────────────────────────┘│
                                                    │
                              ◀─────────────────────┘
```

#### 4.3 wifi_app_soft_ap_config() - Cấu hình Access Point

```c
static void wifi_app_soft_ap_config(void) {
    // Bước 1: Tạo struct cấu hình AP
    wifi_config_t ap_config = {
        .ap = {
            .ssid = WIFI_APP_SSID,           // "ESP32_APP"
            .password = WIFI_APP_PASSWORD,    // "password"
            .channel = WIFI_AP_CHANNEL,       // Kênh 1
            .authmode = WIFI_AUTH_WPA2_PSK,   // Bảo mật WPA2
            .max_connection = WIFI_AP_CONNECTION, // Max 5 devices
        },
    };
    
    // Bước 2: Cấu hình DHCP Server
    esp_netif_dhcps_stop(esp_netif_ap);   // Dừng DHCP trước
    
    // Bước 3: Set IP tĩnh cho AP
    esp_netif_ip_info_t app_ip_info;
    inet_pton(AF_INET, "192.168.0.1", &app_ip_info.ip);
    inet_pton(AF_INET, "192.168.0.1", &app_ip_info.gw);
    inet_pton(AF_INET, "255.255.255.0", &app_ip_info.netmask);
    esp_netif_set_ip_info(esp_netif_ap, &app_ip_info);
    
    // Bước 4: Khởi động DHCP Server
    esp_netif_dhcps_start(esp_netif_ap);
    
    // Bước 5: Set mode và apply config
    esp_wifi_set_mode(WIFI_MODE_APSTA);   // AP + Station mode
    esp_wifi_set_config(ESP_IF_WIFI_AP, &ap_config);
}
```

**📌 WIFI Modes:**
```
┌─────────────────────────────────────────────────────────────────────┐
│ WIFI_MODE_STA   │ Station mode  │ ESP32 kết nối vào WiFi khác      │
│ WIFI_MODE_AP    │ AP mode       │ ESP32 phát WiFi cho người khác   │
│ WIFI_MODE_APSTA │ AP+STA mode   │ Vừa phát vừa kết nối (cả 2)     │
└─────────────────────────────────────────────────────────────────────┘
```

---

### 5️⃣ Event Handler - Xử Lý Sự Kiện WiFi

```
┌─────────────────────────────────────────────────────────────────────┐
│                     WIFI EVENTS FLOW                                 │
└─────────────────────────────────────────────────────────────────────┘

    ┌──────────────┐
    │ WIFI_EVENT   │
    └──────────────┘
          │
          ├──▶ AP_START ─────────────▶ ESP32 bắt đầu phát WiFi
          ├──▶ AP_STOP ──────────────▶ ESP32 dừng phát WiFi
          ├──▶ AP_STACONNECTED ──────▶ Có thiết bị kết nối vào AP
          ├──▶ AP_STADISCONNECTED ───▶ Thiết bị ngắt kết nối khỏi AP
          ├──▶ STA_START ────────────▶ ESP32 bắt đầu tìm WiFi
          ├──▶ STA_CONNECTED ────────▶ ESP32 đã kết nối vào WiFi
          └──▶ STA_DISCONNECTED ─────▶ ESP32 bị ngắt khỏi WiFi

    ┌──────────────┐
    │ IP_EVENT     │
    └──────────────┘
          │
          └──▶ STA_GOT_IP ───────────▶ ESP32 nhận được IP address
```

---

### 6️⃣ RGB LED - Hiển Thị Trạng Thái

```c
// LED GPIO Mapping
#define RGB_LED_RED_GPIO    21    // Chân GPIO 21 → LED Đỏ
#define RGB_LED_GREEN_GPIO  22    // Chân GPIO 22 → LED Xanh
#define RGB_LED_YELLOW_GPIO 23    // Chân GPIO 23 → LED Vàng

// Trạng thái và màu LED
┌─────────────────────────────────────────────────────────────────────┐
│ Trạng thái              │ Hàm gọi                    │ Màu (R,G,Y) │
├─────────────────────────┼────────────────────────────┼─────────────┤
│ WiFi app started        │ rgb_led_wifi_app_started() │ (255,102,255)│
│ HTTP server started     │ rgb_led_http_server_started() │ (204,255,51)│
│ WiFi connected          │ rgb_led_wifi_connected()   │ (0,255,153) │
└─────────────────────────────────────────────────────────────────────┘
```

**PWM Control cho LED:**
```
┌─────────────────────────────────────────────────────────────────────┐
│ LEDC (LED Control) Module của ESP32                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│   LEDC_TIMER_0 ─────┬──▶ LEDC_CHANNEL_0 ──▶ GPIO 21 (RED)          │
│   (100 Hz)          ├──▶ LEDC_CHANNEL_1 ──▶ GPIO 22 (GREEN)        │
│                     └──▶ LEDC_CHANNEL_2 ──▶ GPIO 23 (YELLOW)       │
│                                                                      │
│   Duty Cycle: 0-255 (8-bit resolution)                              │
│   0 = LED tắt, 255 = LED sáng nhất                                  │
└─────────────────────────────────────────────────────────────────────┘
```

---

### 7️⃣ task_common.h - Cấu Hình Task

```c
#define WIFI_APP_TASK_STACK_SIZE 4096  // 4KB RAM cho task
#define WIFI_APP_TASK_PRIORITY   5     // Priority (0-24, cao hơn = ưu tiên)
#define WIFI_APP_TASK_CORE_ID    0     // Chạy trên Core 0 (Core 1 cho app khác)
```

**📌 ESP32 Dual Core:**
```
┌───────────────────────────────────────────────────────────────────┐
│                      ESP32 DUAL CORE                               │
├───────────────────────────────────────────────────────────────────┤
│                                                                    │
│   ┌─────────────┐                    ┌─────────────┐              │
│   │   CORE 0    │                    │   CORE 1    │              │
│   │ (PRO_CPU)   │                    │ (APP_CPU)   │              │
│   ├─────────────┤                    ├─────────────┤              │
│   │ WiFi Task   │                    │ User Tasks  │              │
│   │ System Task │                    │ Bluetooth   │              │
│   └─────────────┘                    └─────────────┘              │
│                                                                    │
│   Khuyến nghị: WiFi/Network chạy Core 0, App logic chạy Core 1   │
└───────────────────────────────────────────────────────────────────┘
```

---

## 🚀 CÁC BƯỚC ĐỂ TỰ VIẾT LẠI PROJECT

### Bước 1: Setup Project
```bash
idf.py create-project ten_project
cd ten_project
```

### Bước 2: Cấu hình menuconfig (nếu cần)
```bash
idf.py menuconfig
```

### Bước 3: Tạo các file theo thứ tự

1. **task_common.h** - Định nghĩa cấu hình task trước
2. **rgb_led.h / rgb_led.c** - Module LED (độc lập)
3. **wifi_app.h** - Định nghĩa macros và declarations
4. **wifi_app.c** - Implement logic WiFi
5. **main.c** - Entry point

### Bước 4: CMakeLists.txt trong main/
```cmake
idf_component_register(
    SRCS "main.c" "wifi_app.c" "rgb_led.c"
    INCLUDE_DIRS "."
)
```

### Bước 5: Build và Flash
```bash
idf.py build
idf.py -p COM3 flash monitor
```

---

## ✅ CHECKLIST KHI TỰ VIẾT

- [ ] Khởi tạo NVS trong `app_main()`
- [ ] Tạo event loop mặc định: `esp_event_loop_create_default()`
- [ ] Khởi tạo TCP/IP stack: `esp_netif_init()`
- [ ] Khởi tạo WiFi với config mặc định: `esp_wifi_init()`
- [ ] Tạo netif cho STA và AP: `esp_netif_create_default_wifi_sta/ap()`
- [ ] Đăng ký event handler cho WIFI_EVENT và IP_EVENT
- [ ] Cấu hình IP tĩnh cho AP (stop DHCP → set IP → start DHCP)
- [ ] Set WiFi mode: `esp_wifi_set_mode()`
- [ ] Apply WiFi config: `esp_wifi_set_config()`
- [ ] Start WiFi: `esp_wifi_start()`

---

## 📚 TÀI LIỆU THAM KHẢO

- [ESP-IDF WiFi Station Example](https://github.com/espressif/esp-idf/tree/master/examples/wifi/getting_started/station)
- [ESP-IDF WiFi SoftAP Example](https://github.com/espressif/esp-idf/tree/master/examples/wifi/getting_started/softAP)
- [FreeRTOS Queue Documentation](https://www.freertos.org/Embedded-RTOS-Queues.html)
- [ESP32 LEDC API](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/ledc.html)

---

## 💡 MẸO GHI NHỚ

```
┌─────────────────────────────────────────────────────────────────────┐
│ THỨ TỰ KHỞI TẠO WIFI (BẮT BUỘC ĐÚNG THỨ TỰ)                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  1. nvs_flash_init()          ─ NVS trước (lưu WiFi credentials)   │
│  2. esp_event_loop_create_default() ─ Event loop cho events        │
│  3. esp_netif_init()          ─ TCP/IP stack                        │
│  4. esp_wifi_init()           ─ WiFi driver                         │
│  5. esp_netif_create_...()    ─ Tạo network interface               │
│  6. Register event handlers   ─ Đăng ký lắng nghe events           │
│  7. Configure WiFi            ─ Set mode, config, IP                │
│  8. esp_wifi_start()          ─ Bật WiFi                            │
│                                                                      │
│  ⚠️  SAI THỨ TỰ = CRASH hoặc KHÔNG HOẠT ĐỘNG                       │
└─────────────────────────────────────────────────────────────────────┘
```

---

*Tạo bởi: GitHub Copilot - 24/12/2024*
