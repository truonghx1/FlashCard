#ifndef MAIN_HTTO_SERVER_H_
#define MAIN_HTTO_SERVER_H_
#include "freertos/semphr.h"

#define OTA_UPDATE_PENDING       0
#define OTA_UPDATE_SUCCESSFUL    1
#define OTA_UPDATE_FAIL         -1

/**
 * Connection status for Wifi
 */
typedef enum http_server_wifi_connect_status{
    NONE = 0,
    HTTP_WIFI_STATUS_CONNECTING,
    HTTP_WIFI_STATUS_CONNECT_FAIL,
    HTTP_WIFI_STATUS_CONNECT_SUCCESS,
    HTTP_WIFI_STATUS_DISCONNECTED
} http_server_wifi_connect_status_e;
/**
 * Message for the HTTP monitor
 * */
typedef enum http_server_message {
    HTTP_MSG_WIFI_CONNECT_INIT = 0,
    HTTP_MSG_WIFI_CONNECT_SUCCESS,
    HTTP_MSG_WIFI_CONNECT_FAIL,
    HTTP_MSG_WIFI_USER_DISCONNECT,
    HTTP_MSG_OTA_UPDATE_SUCCESSFUL,
    HTTP_MSG_OTA_UPDATE_FAILED,
    HTTP_MSG_TIME_SERVICE_INITIALIZED

} http_server_message_e;

/**
 * Struct for the message queue
*/
typedef struct http_server_queue_message
{
    http_server_message_e msgID;
} http_server_queue_message_t;

/**
 * Send a message to queue
 * @param msgID message ID from the http_server_message_e enum
 * @return pdTRUE if an item was successfully to the queue, otherwise pdFhalse
 * @note Can expand
*/

BaseType_t http_server_monitor_send_message(http_server_message_e msgID);

/**
 * Start the http server
*/
void http_server_start(void);

/**
 * Stop http_server
 *  
 */
void http_server_stop(void);

/**
 * Timer callback funtion which calls esp_restart upon successful firmware update
 */
void http_server_fw_update_reset_callback(void *arg);

#endif /*MAIN_HTTO_SERVER_H_*/