#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "gpio.h"
#include "task_common.h"

int gpio_value = -1;
int get_gpio_value(void){
    return gpio_value;
}

/**
 * Reveive value from rest api and set value for it
 * @param val Value reveived
 */
void set_gpio_control_value(int val){
    printf("set_gpio_control_value:  %d", val);
    gpio_set_level(GPIO_CONTROL_PIN, val);
}
/**
 * gpio task
 * 
 */
static void gpio_task(void *pvParameter){

    gpio_reset_pin(GPIO_CONTROL_PIN);
    gpio_set_direction(GPIO_CONTROL_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(GPIO_CONTROL_PIN, 0);

    gpio_reset_pin(GPIO_INPUT_PIN);
    gpio_set_direction(GPIO_INPUT_PIN, GPIO_MODE_INPUT);
    gpio_set_pull_mode(GPIO_INPUT_PIN, GPIO_PULLDOWN_ONLY);
    printf("Starting reading input from pin %d", GPIO_INPUT_PIN);
    for(;;){
        int ret = gpio_get_level(GPIO_INPUT_PIN);
        gpio_value = ret;
        printf("Data read:: %d\n", ret);
        vTaskDelay(1000/portTICK_PERIOD_MS);
    }
}

void gpio_task_start(void){
    xTaskCreatePinnedToCore(&gpio_task, "gpio_task", GPIO_TASK_STACK_SIZE, NULL, GPIO_TASK_PRIORIRY, NULL, GPIO_TASK_CORE_ID);
}