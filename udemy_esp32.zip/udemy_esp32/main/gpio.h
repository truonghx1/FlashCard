#ifndef MAIN_GPIO_H_
#define MAIN_GPIO_H_

#define GPIO_INPUT_PIN  19

#define GPIO_CONTROL_PIN 18
/**
 * Get gpio value
 */
int get_gpio_value(void);

/**
 * Set output for gpio control from rest API
 */
void set_gpio_control_value(int val);

/** 
 * Start reading gpio task
*/
void gpio_task_start(void);
#endif /*MAIN_GPIO_H_*/