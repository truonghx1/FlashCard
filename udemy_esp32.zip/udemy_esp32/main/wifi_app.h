/**
 * @file wifi_app.h
 * @brief Wi-Fi application header file
 *
 * This file contains the declarations and definitions for the Wi-Fi application.
 */

#ifndef WIFI_APP_H
#define WIFI_APP_H

#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_wifi.h"

// Callback typedef
typedef void (*wifi_connected_event_callback_t)(void);

// Wifi application setting
#define WIFI_APP_SSID           "ESP32_APP"      //AP name
#define WIFI_APP_PASSWORD       "password"       //AP password
#define WIFI_AP_CHANNEL          1               //AP channel
#define WIFI_AP_SSID_HIDDEN      0               //AP visibility
#define WIFI_AP_CONNECTION       5               //AP max clients
#define WIFI_AP_BEACON_INTERVAL  100             //AP beacon: 100 milliseconds recommended
#define WIFI_AP_IP               "192.168.0.1"   // AP default IP
#define WIFI_AP_GATEWAY          "192.168.0.1"   // AP default gateway(Should be the same as the IP)
#define WIFI_AP_NETMASK          "255.255.255.0" // AP netmask
#define WIFI_AP_BANDWIDTH        WIFI_BW_HT20    // AP bandwidth 20 MHz(40 MHz is the other option)
#define WIFI_STA_POWER_SAVE      WIFI_PS_NONE    // Power save not use
#define MAX_SSID_LENGTH          32              // IEEE standard maximum
#define MAX_PASSWORD_LENGTH      64              // IEEE standard maximum
#define MAX_CONNECTION_RETRUES   3               // Retry number on disconnect

// netif object for the Station and Access Point
extern esp_netif_t* esp_netif_sta;
extern esp_netif_t* esp_netif_ap;

/**
 * Message IDs for the Wifi application task
 * @note Expand this based on your appilication requirement
 */
typedef enum wifi_app_message{
    WIFI_APP_MSG_START_HTTP_SERVER = 0,
    WIFI_APP_MSG_CONNECTING_FROM_HTTP_SERVER,
    WIFI_APP_MSG_STA_CONNECTED_GOT_IP,
    WIFI_APP_MSG_USER_REQUESTED_STA_DISCONNECT,
    WIFI_APP_MSG_LOAD_SAVED_CREDENTIALS,
    WIFI_APP_MSG_STA_DISCONNECTED
} wifi_app_message_e;

/**
 * Structure for the message queue
 * @note Expand this based on applicatiopn requirements e.g add another type and parameter as requird
 */

 typedef struct wifi_app_queue_message{
    wifi_app_message_e msgID;
 } wifi_app_queue_message_t;
 
/**
 * Send a message to queue
 * @param msgID message ID from the wifi_app_message_e
 * @return pdTRUE if an item was successfully sent to the queue, otherwise pdFALSE
 * @note Expand the parameter list based on your requirements e.g how you've expanded the wifi_app_queue_message_t
 */
BaseType_t wifi_app_send_message(wifi_app_message_e msgID);

/**
 * Start the wifi RTOS task
 */
void wifi_app_start();

/**
 * Get the wifi configuration
 */
wifi_config_t* wifi_app_get_wifi_config(void);

/**
 * Sets the callback function.
 */
void wifi_app_set_callback(wifi_connected_event_callback_t cb);

/**
 * Calls the callback function.
 */
void wifi_app_call_callback(void);

/**
 * Gets the RSSI value of the Wifi connection.
 * @return current RSSI level.
 */
int8_t wifi_app_get_rssi(void);

#endif // WIFI_APP_H
