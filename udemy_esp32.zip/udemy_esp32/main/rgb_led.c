#include <stdbool.h>

#include "driver/ledc.h"

#include "rgb_led.h"
// handle for rgb_led_pwm_init
bool g_pwm_init_handle = false;

ledc_info_t ledc_ch[RGB_LED_CHANNEL_NUM];

/**
 * Initialize the RGB LED setting per channel, including
 * the GPIO for each color, mode and timer configuratuion
 */
static void rgb_led_pwm_init(void){
    int rgb_chn;
    //RED
    ledc_ch[0].channel = LEDC_CHANNEL_0;
    ledc_ch[0].gpio = RGB_LED_RED_GPIO;
    ledc_ch[0].mode = LEDC_HIGH_SPEED_MODE;
    ledc_ch[0].timmer_index = LEDC_TIMER_0;

    //Green
    ledc_ch[1].channel = LEDC_CHANNEL_1;
    ledc_ch[1].gpio = RGB_LED_GREEN_GPIO;
    ledc_ch[1].mode = LEDC_HIGH_SPEED_MODE;
    ledc_ch[1].timmer_index = LEDC_TIMER_0;

    //YELLOW
    ledc_ch[2].channel = LEDC_CHANNEL_2;
    ledc_ch[2].gpio = RGB_LED_YELLOW_GPIO;
    ledc_ch[2].mode = LEDC_HIGH_SPEED_MODE;
    ledc_ch[2].timmer_index = LEDC_TIMER_0;

    //Configure timer zero
    ledc_timer_config_t ledc_timer = {
        .duty_resolution = LEDC_TIMER_8_BIT,
        .freq_hz = 100,
        .speed_mode = LEDC_HIGH_SPEED_MODE,
        .timer_num = LEDC_TIMER_0
    };
    ledc_timer_config(&ledc_timer);

    // Config channels
    for(rgb_chn = 0; rgb_chn < RGB_LED_CHANNEL_NUM; rgb_chn++){
        ledc_channel_config_t ledc_channel = {
            .channel = ledc_ch[rgb_chn].channel,
            .duty = 0,
            .hpoint = 0,
            .gpio_num = ledc_ch[rgb_chn].gpio,
            .intr_type = LEDC_INTR_DISABLE,
            .speed_mode = ledc_ch[rgb_chn].mode,
            .timer_sel = ledc_ch[rgb_chn].timmer_index
        };
        ledc_channel_config(&ledc_channel);
    }
    g_pwm_init_handle = true;
}

/**
 * Set rgb color
 */
static void rgb_led_set_color(uint8_t red, uint8_t green, uint8_t yellow){
    // value should be 0 - 255 for 8 bit number
    ledc_set_duty(ledc_ch[0].mode, ledc_ch[0].channel, red);
    ledc_update_duty(ledc_ch[0].mode, ledc_ch[0].channel);

    ledc_set_duty(ledc_ch[1].mode, ledc_ch[1].channel, green);
    ledc_update_duty(ledc_ch[1].mode, ledc_ch[1].channel);

    ledc_set_duty(ledc_ch[2].mode, ledc_ch[2].channel, yellow);
    ledc_update_duty(ledc_ch[2].mode, ledc_ch[2].channel);

}


void rgb_led_wifi_app_started(void){
    if (!g_pwm_init_handle){
        rgb_led_pwm_init();
    }
    rgb_led_set_color(255, 0, 0);
}


void rgb_led_http_server_started(void){
    if (!g_pwm_init_handle){
        rgb_led_pwm_init();
    }
    rgb_led_set_color(0, 255, 0);
}


void rgb_led_wifi_connected(void){
    if (!g_pwm_init_handle){
        rgb_led_pwm_init();
    }
    rgb_led_set_color(0, 0, 255);
}