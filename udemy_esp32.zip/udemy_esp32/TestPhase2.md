Bạn là kỹ sư Target-based Unit Test cho dự án ESP32 sử dụng ESP-IDF.

Hiện tại tôi chưa có board ESP32 thật.

Nhiệm vụ của bạn là chuẩn bị Giai đoạn 2: Target-based Unit Test để chạy trực tiếp trên ESP32 bằng Unity Framework tích hợp trong ESP-IDF.

Chỉ tạo source test, test firmware chuyên dụng và tài liệu hướng dẫn. Tôi sẽ tự build, flash và chạy test sau khi có board.

Không build, không flash, không mở Serial Monitor và không tuyên bố test đã PASS.

# 1. Mục tiêu

Chuẩn bị Target-based Unit Test cho các module phụ thuộc ESP32, ESP-IDF hoặc FreeRTOS mà Native Unit Test trên PC không kiểm tra chính xác được.

Đối tượng phù hợp bao gồm:

- GPIO
- NVS
- I2C
- SPI
- UART
- ADC
- ESP Timer
- FreeRTOS queue
- FreeRTOS task
- FreeRTOS semaphore
- FreeRTOS event group
- FreeRTOS timer
- ESP event loop
- Driver hoặc component phụ thuộc ESP-IDF runtime

Ưu tiên kiểm tra theo thứ tự:

1. FreeRTOS queue
2. FreeRTOS task và synchronization
3. NVS
4. GPIO
5. I2C hoặc các peripheral khác

Chỉ tạo test cho chức năng thực sự tồn tại trong source.

Không tự tạo API, module, GPIO, NVS namespace, queue, task hoặc expected behavior không tồn tại trong project.

# 2. Công nghệ bắt buộc

Sử dụng duy nhất:

- ESP-IDF
- CMake của ESP-IDF
- Unity Framework tích hợp trong ESP-IDF
- Macro `TEST_CASE`
- ESP-IDF component model
- Firmware test chuyên dụng
- Serial Monitor của ESP-IDF để chọn và xem kết quả test

Không sử dụng:

- PlatformIO
- GoogleTest
- Robot Framework
- Wokwi trong nhiệm vụ này
- Native GCC test
- Arduino Framework
- Mock hardware framework
- Board ESP32 giả
- Docker
- GitHub Actions
- Production credential
- Public network service

Test có thể viết bằng C hoặc C++ tùy ngôn ngữ của module production.

File test phải bắt đầu bằng `test_`.

Ví dụ:

test_gpio_driver.c
test_nvs_storage.c
test_queue_manager.c
test_i2c_driver.cpp

# 3. Giới hạn thay đổi

Được phép đọc toàn bộ repository để phân tích.

Chỉ được phép tạo hoặc chỉnh sửa file bên trong:

test/test_target/

Không được tạo, xóa, đổi tên hoặc chỉnh sửa bất kỳ file nào bên ngoài thư mục này.

Đặc biệt không được chỉnh sửa:

- main/**
- components/**
- test/test_desktop/**
- test/integration/**
- Root CMakeLists.txt
- main/CMakeLists.txt
- sdkconfig
- sdkconfig.defaults
- Partition table
- Bootloader configuration
- .github/**
- Production source code

Nếu `test/test_target/` chưa tồn tại, tạo cấu trúc sau:

test/test_target/
├── CMakeLists.txt
├── README.md
├── sdkconfig.defaults
├── main/
│   ├── CMakeLists.txt
│   └── test_app_main.c
└── components/
    └── target_tests/
        ├── CMakeLists.txt
        └── test_<selected_module>.c

Nếu module test là C++, dùng:

test_<selected_module>.cpp

Chỉ tạo thêm file hoặc thư mục bên trong `test/test_target/` khi thực sự cần thiết.

Không sao chép source production vào `test/test_target/`.

Không sửa production code để làm module dễ test hơn.

# 4. Khảo sát repository

Trước khi tạo file, đọc và phân tích:

- Root CMakeLists.txt
- main/CMakeLists.txt
- Source và header trong main/
- Các component trong components/
- CMakeLists.txt của từng component
- sdkconfig và sdkconfig.defaults nếu tồn tại
- ESP-IDF target chip
- ESP-IDF version nếu xác định được
- GPIO configuration
- NVS namespace và key
- I2C controller, address và pin
- FreeRTOS task
- FreeRTOS queue
- Semaphore, event group và timer
- Public API của module
- Setup và cleanup API
- Các resource được tạo và giải phóng
- Các timeout hiện có
- Dependency của từng module

Lập danh sách module có thể kiểm tra bằng Target-based Unit Test.

Với mỗi module, xác định:

- Module có cần ESP32 thật không
- Có cần đấu dây không
- Có ghi vào flash hoặc NVS không
- Có thể làm thay đổi trạng thái thiết bị không
- Có yêu cầu peripheral bên ngoài không
- Có API cleanup không
- Có thể chạy test lặp lại không
- Có nguy cơ treo task không
- Có nguy cơ block vô hạn không

Chọn một module nhỏ, có giá trị và ít rủi ro nhất để tạo bộ test đầu tiên.

Ưu tiên FreeRTOS queue hoặc task synchronization nếu project có sẵn API phù hợp, vì nhóm này thường không cần đấu nối ngoại vi.

# 5. Phân loại test

Phân loại mỗi test là một trong các loại sau:

## Runtime-only

Chỉ cần ESP-IDF runtime, không cần ngoại vi:

- FreeRTOS queue
- Task
- Semaphore
- Event group
- Software timer
- Internal state transition

## On-chip peripheral

Sử dụng peripheral bên trong ESP32 nhưng có thể không cần thiết bị ngoài:

- NVS
- Internal timer
- Selected ADC/internal functionality khi phù hợp

## Loopback

Cần đấu nối pin của cùng một board:

- GPIO output nối GPIO input
- UART TX nối UART RX
- SPI loopback nếu project hỗ trợ

## External peripheral

Cần thiết bị ngoài:

- I2C sensor
- SPI sensor
- Display
- External ADC
- External interrupt source

Nếu test cần đấu dây hoặc thiết bị ngoài, ghi rõ trong README.

Không giả định thiết bị ngoài đang tồn tại.

# 6. Test plan

Trước khi tạo file, trả về test plan ngắn gồm:

- Module được chọn
- Loại test
- Source production
- Header production
- ESP-IDF dependency
- Hardware requirement
- Wiring requirement
- Setup
- Test cases
- Expected result
- Timeout
- Cleanup
- File sẽ tạo
- Build command dự kiến
- Flash command dự kiến
- Run procedure dự kiến
- Rủi ro

Sau test plan, tiếp tục tạo file mà không hỏi tôi xác nhận.

Nếu không có module nào có public API phù hợp và production code không thể link từ test project mà không sửa file bên ngoài `test/test_target/`, không tạo test giả. Báo trạng thái:

BLOCKED

và giải thích dependency hoặc cấu trúc build gây cản trở.

# 7. Tạo test firmware chuyên dụng

Tạo một ESP-IDF project độc lập trong:

test/test_target/

Root CMakeLists.txt của test project phải:

- Có `cmake_minimum_required`
- Include `$ENV{IDF_PATH}/tools/cmake/project.cmake`
- Khai báo tên project test rõ ràng
- Dùng `EXTRA_COMPONENT_DIRS` để tham chiếu production components khi phù hợp
- Dùng đường dẫn tương đối chính xác từ `test/test_target/`
- Không chỉnh sửa root CMakeLists.txt của production project
- Không copy source production
- Không hardcode đường dẫn tuyệt đối trên máy
- Không hardcode IDF_PATH
- Không phụ thuộc username hoặc ổ đĩa cụ thể

Tên project đề xuất:

udemy_esp32_target_tests

Chỉ thêm production component thực sự cần cho module được test.

Không đưa toàn bộ application vào test firmware nếu không cần thiết.

Nếu module nằm trực tiếp trong `main/` và không thể được dùng như một reusable component, không tự ý copy module hoặc sửa `main/CMakeLists.txt`.

Trong trường hợp đó:

- Tạo phần khung test project hợp lệ trong `test/test_target/`
- Không tạo test không thể link
- Ghi rõ `BLOCKED_BY_COMPONENT_STRUCTURE`
- Trong README, đề xuất tách module thành ESP-IDF component như một bước tương lai
- Không thực hiện việc refactor trong nhiệm vụ này

# 8. Tạo Unity test runner

Tạo:

test/test_target/main/test_app_main.c

Test runner phải:

- Include `unity.h`
- Có `app_main()`
- In banner ngắn cho target test firmware
- In tổng số test được đăng ký nếu API hiện tại hỗ trợ
- Chạy Unity test menu để người dùng chọn test qua Serial Monitor
- Cho phép chạy test theo index, theo tag hoặc chạy tất cả
- Không tự động reboot vô hạn
- Không chứa production application logic
- Không chứa credential
- Không gọi API không tồn tại trong ESP-IDF version của project

Ưu tiên sử dụng API Unity test runner được ESP-IDF version hiện tại hỗ trợ.

Không viết lại nội bộ của Unity framework.

Không khai báo `UNITY_BEGIN()` và `UNITY_END()` bên trong từng `TEST_CASE`.

# 9. Tạo test component

Tạo:

test/test_target/components/target_tests/CMakeLists.txt

Yêu cầu:

- Đăng ký test source bằng `idf_component_register`
- Khai báo `REQUIRES unity`
- Khai báo production component được test trong `REQUIRES` hoặc `PRIV_REQUIRES`
- Chỉ include dependency thực sự cần
- Không dùng glob ngoài phạm vi test component nếu không cần
- Không hardcode absolute include path

ESP-IDF test component tối thiểu phải phụ thuộc `unity`.

Ví dụ về nguyên tắc, không sao chép máy móc nếu project cần dependency khác:

idf_component_register(
    SRC_DIRS "."
    INCLUDE_DIRS "."
    REQUIRES unity <production_component>
)

Nếu production module nằm trong `main/` và không thể khai báo dependency component hợp lệ, không thêm đường dẫn include giả và không include trực tiếp file `.c`.

# 10. Viết TEST_CASE

Dùng cú pháp Unity của ESP-IDF:

TEST_CASE("descriptive test name", "[module][target]")
{
    // Setup
    // Execute
    // Assert
    // Cleanup
}

Tag phải rõ ràng, ví dụ:

- `[freertos][queue]`
- `[freertos][task]`
- `[nvs]`
- `[gpio]`
- `[i2c]`
- `[uart]`
- `[timer]`

Mỗi test chỉ kiểm tra một behavior hoặc failure mode chính.

Tên test phải mô tả hành vi, không dùng tên chung như:

- test1
- basic test
- module test

Không viết test phụ thuộc thứ tự chạy.

Không dùng biến global có trạng thái tồn tại giữa các test trừ khi được reset hoàn toàn trong setup và cleanup.

# 11. Quy tắc chung cho test

Mỗi test phải:

- Có setup rõ ràng
- Có timeout hữu hạn
- Có assertion rõ ràng
- Có cleanup
- Có thể chạy lặp lại
- Không phụ thuộc test trước
- Không chứa vòng lặp vô hạn
- Không dùng `portMAX_DELAY`
- Không dùng delay dài tùy ý
- Không giữ task, queue, timer, semaphore hoặc driver sau khi kết thúc
- Không làm hỏng production data
- Không xóa toàn bộ flash
- Không thay đổi eFuse
- Không thay đổi secure boot
- Không thay đổi flash encryption
- Không truy cập production server
- Không chứa Wi-Fi password
- Không chứa secret hoặc token

Dùng timeout theo milliseconds và chuyển đổi bằng API FreeRTOS phù hợp.

Ưu tiên event, queue hoặc semaphore thay vì delay cố định.

Sau test, phải kiểm tra và giải phóng tất cả resource được tạo.

# 12. FreeRTOS queue test

Nếu project có module queue phù hợp, kiểm tra tối thiểu:

- Tạo hoặc khởi tạo queue thành công
- Gửi item hợp lệ
- Nhận đúng item
- Bảo toàn dữ liệu
- Queue empty timeout
- Queue full behavior
- Invalid input nếu API production hỗ trợ
- Cleanup queue
- Có thể init/deinit lại

Không dùng `portMAX_DELAY`.

Không để task test block vô hạn.

Nếu tạo helper task:

- Kiểm tra kết quả `xTaskCreate`
- Có cơ chế báo hoàn tất
- Có timeout chờ helper task
- Xóa task khi test kết thúc
- Không để task tiếp tục chạy sau test

# 13. FreeRTOS task và synchronization test

Nếu project có task hoặc synchronization API phù hợp, kiểm tra:

- Task được tạo thành công
- Task báo readiness
- Task xử lý một input
- Task phát output hoặc signal
- Timeout khi không có input
- Semaphore hoặc event bit đúng
- Task dừng đúng cách nếu API hỗ trợ
- Resource được cleanup

Không assertion trực tiếp từ nhiều task nếu cách đó không an toàn.

Ưu tiên helper task gửi kết quả về test task qua queue, notification hoặc semaphore.

# 14. NVS test

Nếu project có NVS wrapper hoặc storage module, kiểm tra:

- Init
- Ghi giá trị
- Đọc lại giá trị
- Ghi đè
- Key không tồn tại
- Invalid input nếu API hỗ trợ
- Commit behavior
- Deinit
- Cleanup dữ liệu test

Dùng namespace dành riêng cho test, ví dụ:

target_test

Không dùng hoặc xóa production namespace.

Không chạy:

idf.py erase-flash

Không xóa toàn bộ NVS partition.

Chỉ xóa key hoặc namespace được test tạo ra.

Tên namespace và key test phải rõ ràng và không xung đột production data.

Nếu project sử dụng custom NVS partition, không tự đoán partition name.

# 15. GPIO test

Chỉ tạo GPIO test nếu pin được xác định rõ từ source hoặc configuration.

Nếu cần loopback:

- Chọn output GPIO và input GPIO dựa trên project hoặc ghi placeholder có cảnh báo rõ ràng
- Không dùng flash pin
- Không dùng PSRAM pin
- Không dùng USB/JTAG pin nếu target có hạn chế
- Không tự đoán pin an toàn
- Ghi wiring trong README

Test GPIO loopback phải:

1. Configure output.
2. Configure input.
3. Set output low.
4. Xác nhận input low.
5. Set output high.
6. Xác nhận input high.
7. Reset pin khi cleanup.

Nếu không xác định được pin an toàn, không tạo GPIO test executable giả. Chỉ ghi test design và trạng thái blocked.

# 16. I2C test

Chỉ tạo I2C test nếu production code có:

- I2C port
- SDA GPIO
- SCL GPIO
- Device address
- Driver initialization API
- Read hoặc write API

Test phải ghi rõ thiết bị ngoài cần thiết.

Kiểm tra phù hợp có thể gồm:

- Driver init
- Device probe
- Read device ID nếu thiết bị hỗ trợ
- Timeout khi device không phản hồi
- Driver deinit
- Reinitialize

Không hardcode sensor register hoặc device ID nếu không tồn tại trong production source hoặc datasheet đã được project sử dụng.

Không xem việc không tìm thấy thiết bị là PASS.

# 17. sdkconfig.defaults

Tạo:

test/test_target/sdkconfig.defaults

Chỉ thêm option thực sự cần cho test firmware.

Không sao chép toàn bộ production sdkconfig.

Không kích hoạt:

- Secure boot
- Flash encryption
- Destructive flash behavior
- Production Wi-Fi credential
- Production certificate
- OTA
- Automatic flash erase

Nếu chưa xác định cần option nào, để file có comment giải thích hoặc không thêm cấu hình không cần thiết.

# 18. README

Tạo:

test/test_target/README.md

README phải hướng dẫn theo đúng thứ tự sau.

## Purpose

Giải thích đây là Target-based Unit Test chạy trên ESP32 thật bằng ESP-IDF Unity.

Ghi rõ test chưa được build hoặc chạy.

## Prerequisites

- ESP-IDF extension hoặc ESP-IDF terminal hoạt động
- ESP-IDF version phù hợp project
- Board đúng target
- USB data cable
- Serial driver nếu hệ điều hành yêu cầu
- Wiring hoặc external peripheral nếu test cần

## Hardware requirements

Liệt kê:

- ESP32 target
- Board assumption
- GPIO wiring
- I2C sensor
- NVS behavior
- Peripheral requirement

Nếu chưa xác định board cụ thể, ghi rõ:

BOARD_MODEL_REQUIRED

Không tự đoán board.

## Build later

Từ root repository:

idf.py -C test/test_target set-target <actual-target>
idf.py -C test/test_target build

Hoặc hướng dẫn tương đương nếu ESP-IDF version của project không hỗ trợ `-C`.

Không ghi target giả nếu chưa xác định được từ project.

## Flash later

idf.py -C test/test_target -p <serial-port> flash

Ghi rõ:

- Thay `<serial-port>` bằng cổng thực tế
- Không hardcode COM3
- Không hardcode `/dev/ttyUSB0`
- Flash sẽ thay firmware hiện tại trên board
- Không chạy erase-flash

## Monitor later

idf.py -C test/test_target -p <serial-port> monitor

Hoặc:

idf.py -C test/test_target -p <serial-port> flash monitor

## Run Unity tests

Mô tả cách sử dụng menu Unity:

- Nhập index để chạy một test
- Nhập tên test nếu runner hỗ trợ
- Nhập tag như `[freertos]` hoặc `[nvs]`
- Nhập `*` để chạy tất cả nếu Unity runner của ESP-IDF version hiện tại hỗ trợ

Không khẳng định command menu nếu API hoặc version hiện tại không hỗ trợ.

## Expected output

Mô tả:

- Test name
- PASS hoặc FAIL từ Unity
- Assertion failure
- Test summary

Không tạo log output giả như thể test đã chạy.

## Troubleshooting

Bao gồm:

- Không tìm thấy IDF_PATH
- Sai target chip
- Production component không được link
- Không tìm thấy test trong menu
- Serial port busy
- Permission denied trên serial port
- Board không vào download mode
- GPIO loopback chưa đấu
- I2C device không phản hồi
- NVS test fail do partition configuration
- Task hoặc queue timeout
- Watchdog reset
- Undefined reference khi link test firmware

## Cleanup

Mô tả:

- Stop monitor
- Reset pin
- Xóa riêng test NVS keys
- Tháo loopback wiring khi cần
- Flash lại production firmware sau khi test

## Limitations

Ghi rõ:

- Test chưa được build
- Test chưa được flash
- Test chưa được execute
- Chưa xác minh trên board thật
- Board model hoặc wiring có thể cần điều chỉnh
- Simulator không thay thế kết quả target-based test trên chip thật

# 19. Không build và không chạy

Trong nhiệm vụ này tuyệt đối không:

- Chạy `idf.py build`
- Chạy `idf.py flash`
- Chạy `idf.py monitor`
- Chạy `idf.py erase-flash`
- Mở serial port
- Chạy Unity test
- Kết nối board
- Cài package
- Chạy Wokwi
- Chạy PlatformIO
- Tuyên bố PASS
- Tuyên bố BUILD_PASS

Tôi sẽ tự build, flash và chạy sau khi có ESP32.

Trạng thái cuối cùng bắt buộc là:

NOT_EXECUTED

Nếu không thể tạo test hợp lệ do cấu trúc component, thiếu public API hoặc thiếu thông tin target, sử dụng:

BLOCKED

hoặc mô tả chi tiết:

BLOCKED_BY_COMPONENT_STRUCTURE
BLOCKED_BY_MISSING_HARDWARE_DEFINITION
BLOCKED_BY_MISSING_PUBLIC_API

# 20. Kiểm tra tĩnh trước khi kết thúc

Không thực thi build hoặc test, nhưng phải kiểm tra bằng cách đọc lại file:

1. CMake syntax có cấu trúc hợp lý.
2. Test project không dùng absolute path.
3. Test component khai báo `REQUIRES unity`.
4. Production component dependency được khai báo đúng tên.
5. Mỗi test file bắt đầu bằng `test_`.
6. Mỗi test dùng `TEST_CASE`.
7. Mỗi blocking operation có timeout.
8. Không có `portMAX_DELAY`.
9. Mỗi resource đều có cleanup.
10. Không có erase-flash.
11. Không có eFuse operation.
12. Không có credential.
13. Không có serial port hardcode.
14. Không có GPIO tự suy đoán.
15. Không include trực tiếp production `.c`.
16. Không có production file bị chỉnh sửa.
17. Mọi file được tạo hoặc chỉnh sửa đều nằm trong `test/test_target/`.

Nếu Copilot vô tình thay đổi file ngoài `test/test_target/`, hoàn tác riêng thay đổi đó.

Không hoàn tác thay đổi có sẵn của người dùng.

Không commit và không push Git.

# 21. Báo cáo cuối cùng

Trả về báo cáo ngắn đúng cấu trúc:

## Classification

- Stage: Target-based Unit Test
- Framework: ESP-IDF Unity
- Selected module
- Test type: runtime-only, on-chip peripheral, loopback hoặc external peripheral

## Hardware requirements

- ESP32 target
- Board requirement
- Wiring
- External peripheral

## Files created

Liệt kê tất cả file đã tạo hoặc chỉnh sửa.

Xác nhận mọi thay đổi nằm trong:

test/test_target/

## Prepared test cases

Liệt kê:

- Test name
- Unity tags
- Setup
- Expected behavior
- Timeout
- Cleanup

## Commands for me to run later

Liệt kê đúng thứ tự:

1. Set ESP-IDF target
2. Build test firmware
3. Connect board
4. Flash test firmware
5. Open monitor
6. Select test
7. Record Unity result
8. Flash production firmware again if needed

## Status

Chỉ dùng:

NOT_EXECUTED

hoặc trạng thái BLOCKED phù hợp.

## Limitations

- Chưa có board
- Chưa build
- Chưa flash
- Chưa chạy test
- Hardware hoặc wiring chưa xác minh

## Next step

Chỉ đưa ra một bước tiếp theo cụ thể.

Bắt đầu bằng việc khảo sát repository.

Chọn một module phụ thuộc ESP-IDF hoặc FreeRTOS nhưng có public API rõ ràng và ít yêu cầu phần cứng nhất.

Ưu tiên FreeRTOS queue hoặc task synchronization trước GPIO, NVS và I2C.

Không tự tạo behavior không tồn tại trong source.
``