Bạn là kỹ sư kiểm thử C/C++ cho dự án ESP32 sử dụng ESP-IDF.

Nhiệm vụ của bạn là thiết lập Giai đoạn 1: Native Unit Test chạy trên PC bằng GoogleTest, CMake và CTest.

## Phạm vi bắt buộc

Chỉ được phép tạo hoặc chỉnh sửa file bên trong thư mục:

test/test_desktop/

Không được tạo, xóa, đổi tên hoặc chỉnh sửa bất kỳ file nào bên ngoài thư mục này.

Đặc biệt, không được chỉnh sửa:

- main/

Bạn được phép đọc và phân tích các file bên ngoài `test/test_desktop/`, đặc biệt là `main/`, nhưng tuyệt đối không được chỉnh sửa chúng.

Nếu `test/` hoặc `test/test_desktop/` chưa tồn tại, chỉ tạo đúng đường dẫn:

test/test_desktop/

Không tạo `test_target`, `integration` hoặc bất kỳ thư mục test nào khác.

## Công nghệ bắt buộc

Sử dụng duy nhất:

- GoogleTest
- CMake
- CTest
- GCC hoặc Clang trên PC

Không sử dụng:

- Robot Framework
- PlatformIO
- ESP-IDF Unity
- ESP-IDF target test
- Wokwi
- Docker
- Python test framework
- Mock framework không cần thiết

Production code có thể là C hoặc C++. Test phải được viết bằng C++ với phần mở rộng `.cpp`.

## Mục tiêu kiểm thử

Chỉ kiểm thử logic có thể chạy native trên PC, ví dụ:

- Thuật toán
- Tính toán CRC hoặc checksum
- Xử lý chuỗi
- Validation
- Parser JSON
- Parser protocol
- Codec
- State machine không phụ thuộc phần cứng
- Chuyển đổi dữ liệu
- Tính toán số học

Không viết native test cho module phụ thuộc trực tiếp vào:

- GPIO
- I2C
- SPI
- UART phần cứng
- ADC
- NVS
- Wi-Fi
- BLE
- FreeRTOS task, queue, timer, semaphore
- ESP event loop
- ESP-IDF runtime
- Các API chỉ tồn tại trên ESP32

## Quy trình thực hiện

### Bước 1: Khảo sát

Đọc cấu trúc dự án và phân tích source code trong:

- main/

Tìm các module có logic thuần túy phù hợp để chạy trên PC.

Kiểm tra mỗi module về:

- Header được include
- API ESP-IDF được sử dụng
- Phụ thuộc phần cứng
- Phụ thuộc FreeRTOS
- Khả năng compile độc lập bằng GCC hoặc Clang
- Hàm public có thể kiểm thử
- Các trường hợp biên và lỗi đầu vào

Không được sửa source production để làm cho module có thể test.

Nếu không có module nào có thể compile native mà không sửa production code, dừng việc tạo test giả và báo trạng thái `BLOCKED`, kèm danh sách dependency gây cản trở.

### Bước 2: Lập kế hoạch

Trước khi tạo file, trình bày một test plan ngắn gồm:

- Module được chọn
- Source file
- Header file
- Lý do module phù hợp với Native Unit Test
- Dependency cần thiết
- Test case dự kiến
- File sẽ tạo trong `test/test_desktop/`
- Lệnh configure
- Lệnh build
- Lệnh chạy test

Không yêu cầu tôi xác nhận nếu đã xác định được module an toàn để test. Sau test plan, tiếp tục triển khai.

### Bước 3: Tạo cấu trúc

Chỉ tạo cấu trúc cần thiết bên dưới:

test/test_desktop/
├── CMakeLists.txt
└── test_<module>.cpp

Chỉ tạo thêm subfolder bên trong `test/test_desktop/` nếu thực sự cần thiết.

Không sao chép production code vào thư mục test.

CMake phải compile trực tiếp source production từ `main/` hoặc `components/` bằng đường dẫn tương đối, nhưng không chỉnh sửa source đó.

### Bước 4: Cấu hình CMake

Tạo `test/test_desktop/CMakeLists.txt` với các yêu cầu:

1. Khai báo project hỗ trợ C và C++.
2. Sử dụng C11 cho source C.
3. Sử dụng C++17 cho GoogleTest.
4. Bật CTest bằng `enable_testing()`.
5. Tích hợp GoogleTest bằng CMake `FetchContent`.
6. Pin GoogleTest vào một release/tag cụ thể; không sử dụng nhánh `main`.
7. Tạo một static library cho module production cần test.
8. Chỉ đưa source native-compatible vào static library.
9. Khai báo include directory chính xác.
10. Tạo executable `desktop_unit_tests`.
11. Link với:
    - Static library của module
    - `GTest::gtest_main`
12. Dùng `gtest_discover_tests()` để đăng ký test với CTest.
13. Bật compiler warnings:
    - `-Wall`
    - `-Wextra`
    - `-Wpedantic`
14. Không dùng option chỉ hỗ trợ GCC/Clang nếu compiler hiện tại không hỗ trợ.
15. Không thay đổi CMakeLists.txt ở root hoặc trong `main/`.

CMake configure phải được chạy từ root repository bằng:

cmake -S test/test_desktop -B build/test_desktop -DCMAKE_BUILD_TYPE=Debug

Build bằng:

cmake --build build/test_desktop --parallel

Chạy test bằng:

ctest --test-dir build/test_desktop --output-on-failure

Thư mục `build/test_desktop` là build output, không phải source test. Không đặt generated file vào `test/test_desktop/`.

### Bước 5: Viết test

Tạo test bằng GoogleTest.

Nếu production module là C, include header theo dạng:

extern "C"
{
#include "<production_header>.h"
}

Mỗi test phải:

- Có tên mô tả hành vi
- Chỉ kiểm tra một hành vi hoặc failure mode chính
- Không phụ thuộc thứ tự chạy
- Không phụ thuộc ESP32
- Không sử dụng thời gian chờ tùy ý
- Không sử dụng network
- Không sử dụng serial port
- Không sử dụng phần cứng thật
- Không chứa credential
- Có kết quả xác định và lặp lại được

Phải kiểm tra tối thiểu các nhóm phù hợp với module:

- Trường hợp hợp lệ thông thường
- Giá trị biên
- Input rỗng
- Input sai định dạng
- Null pointer nếu API cho phép kiểm tra
- Giới hạn buffer
- Giá trị ngoài phạm vi
- Error code
- Known test vector đối với CRC/checksum

Không tự suy đoán expected value cho CRC hoặc checksum. Chỉ sử dụng known test vector đáng tin cậy hoặc expected value đã có trong dự án.

Không viết test truy cập hàm `static` hoặc private implementation bằng thủ thuật như include trực tiếp file `.c` vào test.

### Bước 6: Build và chạy

Sau khi tạo file:

1. Chạy CMake configure.
2. Chạy build.
3. Chạy CTest.
4. Nếu configure hoặc build thất bại, đọc lỗi và chỉ chỉnh sửa file trong `test/test_desktop/`.
5. Không sửa production code để ép test build thành công.
6. Sau khi sửa, chạy lại configure, build và test.
7. Không chạy `idf.py`.
8. Không flash board.
9. Không chạy target test.

Nếu môi trường không có mạng và GoogleTest chưa được tải:

- Không thay framework.
- Không dùng framework khác.
- Báo trạng thái `BLOCKED`.
- Ghi rõ GoogleTest không thể được tải.
- Vẫn giữ cấu hình CMake hợp lệ nếu đã tạo.

## Quy tắc trạng thái

Chỉ sử dụng các trạng thái sau:

- PASS: Test đã thực sự được execute và tất cả test đều pass.
- FAIL: Test đã execute và có ít nhất một test fail.
- BUILD_PASS: Build thành công nhưng test chưa được execute.
- NOT_EXECUTED: Test đã được tạo nhưng chưa chạy.
- BLOCKED: Không thể tiếp tục do dependency, compiler, CMake, network hoặc module production không tương thích native.

Không được báo `PASS` chỉ vì build thành công.

## Kiểm tra giới hạn thay đổi

Trước khi kết thúc:

1. Kiểm tra danh sách file đã tạo hoặc chỉnh sửa.
2. Xác nhận mọi thay đổi đều nằm trong `test/test_desktop/`.
3. Nếu phát hiện thay đổi ngoài phạm vi, hoàn tác thay đổi đó.
4. Không xóa hoặc hoàn tác thay đổi có sẵn của người dùng.
5. Không commit và không push Git.

## Báo cáo cuối cùng

Trả về báo cáo ngắn theo đúng cấu trúc:

### Classification
- Stage: Native Unit Test
- Framework: GoogleTest + CMake + CTest
- Module được test

### Files
- File đã tạo
- File đã chỉnh sửa
- Xác nhận tất cả nằm trong `test/test_desktop/`

### Test cases
- Danh sách test case đã triển khai

### Execution
- Lệnh configure
- Lệnh build
- Lệnh test
- Kết quả thực tế

### Status
Một trong:
PASS, FAIL, BUILD_PASS, NOT_EXECUTED hoặc BLOCKED

### Limitations
- Module chưa thể native test
- Dependency chưa đáp ứng
- Test chưa thực thi được

### Next step
- Chỉ đưa ra một bước tiếp theo cụ thể

Bắt đầu bằng việc khảo sát repository. Chọn một module logic thuần túy nhỏ và có giá trị nhất để tạo bộ Native Unit Test đầu tiên.
Hiện tại chưa build được, nên chỉ tạo hướng dẫn, và các file testcase sẵn. guidle hướng dẫn build.