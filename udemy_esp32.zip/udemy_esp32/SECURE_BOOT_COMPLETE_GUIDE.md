# CẨM NANG TOÀN TẬP VỀ SECURE BOOT & CRYPTOGRAPHY (ESP32)

Tài liệu này tổng hợp kiến thức từ cơ bản đến nâng cao về Secure Boot, quy trình ký số, quản lý khóa và triển khai thực tế trên ESP32.

---

## PHẦN 1: KHÁI NIỆM CỐT LÕI

### 1. Secure Boot là gì?
Secure Boot là "cánh cổng bảo vệ" đầu tiên của thiết bị nhúng. Nó đảm bảo rằng thiết bị chỉ chạy các phần mềm (firmware) do chính nhà sản xuất phát hành và ký duyệt.

**Mục tiêu bảo vệ:**
*   **Chống mã độc (Anti-Malware):** Ngăn chặn hacker cài cắm code gián điệp.
*   **Chống Firmware lạ (Unauthorized):** Chỉ firmware "chính chủ" mới được chạy.
*   **Chống Rollback:** Ngăn kẻ tấn công hạ cấp về phiên bản cũ có lỗi bảo mật.

### 2. Các thành phần Mật mã (Cryptography)

Để vận hành Secure Boot, ta cần sự phối hợp của 3 loại thuật toán:

| Thuật toán | Loại | Input / Output | Vai trò trong Secure Boot |
|:---:|:---:|:---|:---|
| **SHA-256** | Hàm băm (Hash) | Data bất kỳ $\rightarrow$ Chuỗi 256-bit | Tạo "vân tay" duy nhất cho Firmware. Đảm bảo tính toàn vẹn. |
| **RSA / ECDSA** | Bất đối xứng (Asymmetric) | **Sign:** Hash + Private Key $\rightarrow$ Signature<br>**Verify:** Signature + Public Key $\rightarrow$ T/F | Xác thực nguồn gốc. Chứng minh "Tôi là người chủ thực sự". |
| **AES-256** | Đối xứng (Symmetric) | Data + Key $\rightarrow$ Data rác | (Thường dùng cho **Flash Encryption**) Bảo mật nội dung code để không ai đọc được. |

---

## PHẦN 2: QUY TRÌNH KÝ SỐ (SIGNING PROCESS)

Đây là quy trình biến một file `firmware.bin` bình thường thành một file an toàn `firmware_signed.bin`.

### Quy trình kỹ thuật (Under the hood)

1.  **Input:** File `firmware.bin` và `private_key.pem`.
2.  **Hashing:** Máy tính tính toán SHA-256 của `firmware.bin` $\rightarrow$ ra chuỗi `Hash Digest`.
3.  **Signing:** Máy tính dùng `private_key.pem` để mã hóa chuỗi `Hash Digest` $\rightarrow$ ra `Signature Block` (khối chữ ký).
4.  **Packaging:**
    *   Trên máy tính (Dev): Gộp `firmware.bin` + `Signature Block` lại.
    *   **Output:** `firmware_signed.bin` (File này dùng để nạp qua dây hoặc OTA).

---

## PHẦN 3: CƠ CHẾ HOẠT ĐỘNG (CHAIN OF TRUST)

Điều gì xảy ra khi bạn cấp điện cho ESP32?

1.  **Power On:** ROM Code (phần cứng không thể thay đổi) chạy đầu tiên.
2.  **Load Key:** ROM đọc **Hash của Public Key** từ **eFuse** (phần cứng lưu trữ vĩnh viễn).
3.  **Read Flash:** ROM đọc `firmware_signed.bin` từ thẻ nhớ Flash.
4.  **Verification:**
    *   ROM tách phần *Nội dung* và phần *Chữ ký*.
    *   Tự tính Hash của *Nội dung*.
    *   Dùng Public Key (từ eFuse) để giải mã *Chữ ký*.
    *   **So sánh:** Hash tự tính == Hash giải mã?
5.  **Decision:**
    *   ✅ **Khớp:** Nhảy vào chạy Firmware (Boot).
    *   ❌ **Sai:** Treo chip (Halt/Brick) để bảo vệ.

---

## PHẦN 4: QUẢN LÝ KHÓA (KEY MANAGEMENT) - QUAN TRỌNG

### 1. Nguyên tắc sống còn
*   **Private Key (Khóa bí mật):** Dùng để KÝ. **Tuyệt đối bí mật**. Mất cái này là mất quyền kiểm soát toàn bộ thiết bị. Nếu lộ, hacker có thể ký malware.
*   **Public Key (Khóa công khai):** Dùng để KIỂM TRA. Được nạp vào thiết bị. Lộ cũng không sao (vì hacker chỉ dùng nó để verify được thôi, không ký được).

### 2. Vòng đời của Key (Lifecycle)

| Giai đoạn | Hành động | Vị trí Key |
|:---|:---|:---|
| **Sản xuất (Factory)** | 1. Tạo cặp Key.<br>2. Nạp (Burn) Hash của Public Key vào eFuse.<br>3. Bật bit Write Protect (Khóa ghi vĩnh viễn). | Public Key nằm chết trong Chip.<br>Private Key cất trong két sắt (HSM/Cloud). |
| **Vận hành (User)** | Chip chạy bình thường. | Chip chỉ chứa Public Key. |
| **Cập nhật (OTA)** | 1. Dev lấy Private Key ra ký firmware mới.<br>2. Gửi file đã ký qua mạng.<br>3. Chip nhận và tự verify. | Key không bao giờ truyền qua mạng. |

---

## PHẦN 5: MÔI TRƯỜNG DEV vs. PRODUCTION

Làm sao để học mà không làm hỏng chip?

### Môi trường DEV (An toàn cho ví tiền)
*   **Cấu hình:** Chọn mode "Reflashable" trong `menuconfig`.
*   **Hành vi:**
    *   Vẫn nạp Public Key vào eFuse.
    *   **NHƯNG KHÔNG** khóa cứng (Không bật Write Protect).
    *   **KHÔNG** tắt JTAG/UART Debug.
*   **Hệ quả:** Bạn có thể nạp lại key khác, hoặc reset eFuse (nếu chip hỗ trợ hoặc chưa burn hết slot). Chấp nhận hy sinh 1 board dev để test quy trình.

### Môi trường PRODUCTION (Sản phẩm thật)
*   **Cấu hình:** Chọn mode "Release / One-time Flash".
*   **Hành vi:**
    *   Nạp Public Key $\rightarrow$ Đốt eFuse.
    *   Đốt ngay bit **Write Protect** $\rightarrow$ eFuse đóng băng vĩnh viễn.
    *   Vô hiệu hóa JTAG/UART Bootloader.
*   **Hệ quả:** Chip chỉ chạy đúng firmware của bạn. Không thể nạp lại key, không thể debug phần cứng.

---

## PHẦN 6: CÁC CÂU HỎI THƯỜNG GẶP (FAQ)

### Q1: Hacker có thể nạp Public Key của hắn vào chip không?
**Trả lời:** **KHÔNG.**
Vì eFuse là bộ nhớ "đốt một lần" (One-Time Programmable) và được bảo vệ bởi bit Write Protect.
*   Hắn không thể sửa bit 1 thành 0.
*   Hắn không thể ghi thêm bit 1 vì mạch ghi đã bị ngắt (bởi Write Protect).
*   *Trừ khi hắn tấn công chuỗi cung ứng: mua chip trắng, nạp key của hắn rồi mới bán cho bạn.*

### Q2: Nếu lộ Private Key thì sao?
**Trả lời:** Thảm họa. Hacker có thể tạo firmware giả.
**Giải pháp:** Dùng tính năng **Key Revocation (Thu hồi khóa)** của ESP32.
1.  Tạo firmware mới, ký bằng Key mới (Key 2).
2.  Trong firmware này có lệnh đốt bỏ Key 1 trong eFuse.
3.  Khi người dùng update, chip sẽ hủy tin tưởng Key 1 và chuyển sang Key 2.

### Q3: Có bao nhiêu Key có thể lưu trên board?
**Trả lời:** ESP32 hỗ trợ lưu tối đa **3 Public Keys** (Slot 0, 1, 2) để dự phòng cho việc xoay vòng hoặc thu hồi khóa.

---

## PHẦN 7: THỰC HÀNH MÔ PHỎNG (TRÊN LINUX/UBUNTU)

Script này giúp bạn hiểu quy trình mà không cần phần cứng:

```bash
#!/bin/bash
# 1. Tạo nội dung Firmware
echo "Firmware Code v1.0" > firmware.bin

# 2. Tạo cặp khóa RSA 3072 (Chuẩn ESP32 V2)
openssl genrsa -out private.pem 3072
openssl rsa -in private.pem -pubout -out public.pem

# 3. KÝ (Hash -> Sign -> Append)
# Bước này công cụ của ESP làm tự động, ở đây ta làm thủ công
openssl dgst -sha256 -sign private.pem -out signature.bin firmware.bin
cat firmware.bin signature.bin > firmware_signed_ota.bin

echo "Đã tạo file OTA: firmware_signed_ota.bin"

# 4. REVIEW (Giả lập chip verify)
# Chip sẽ tách file OTA ra, lấy phần đầu làm data, phần đuôi làm chữ ký
# Ở đây ta dùng lệnh openssl verify để mô phỏng logic đó
openssl dgst -sha256 -verify public.pem -signature signature.bin firmware.bin

# Kết quả: "Verified OK" là thành công!
```
